
import { VaxServeItem } from './types';

export const VAXSERVE_ITEMS: VaxServeItem[] = [
  {
    productName: "YF-VAX®",
    description: "Yellow Fever Vaccine",
    details: "5 Single-Dose Vials of Lyophilized Vaccine With 5 Single-Dose Vials of Diluent",
    ndc: "49281091501",
    itemNumber: "482756",
    manufacturer: "SANOFI PASTEUR & AFFILIATES",
    price: 1281.58,
    doseCount: 5,
    status: "IN_STOCK"
  }
];
