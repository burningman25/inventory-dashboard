
import React from 'react';
import { InfusionItem, OrderUnit, OrderSelection } from '../types';

interface InventoryTableProps {
  items: InfusionItem[];
  selectedItems: Record<string, OrderSelection>;
  onSelectionChange: (besNumber: string, isSelected: boolean, quantity?: number, unit?: OrderUnit) => void;
  onSelectAll: (isSelected: boolean) => void;
  onSort?: (key: keyof InfusionItem) => void;
  currentSort?: { key: keyof InfusionItem; direction: 'asc' | 'desc' } | null;
}

const InventoryTable: React.FC<InventoryTableProps> = ({ 
  items, 
  selectedItems, 
  onSelectionChange, 
  onSelectAll,
  onSort, 
  currentSort 
}) => {
  const isAllSelected = items.length > 0 && items.every(item => !!selectedItems[item.bes_number]);

  const renderSortIcon = (key: keyof InfusionItem) => {
    if (currentSort?.key !== key) return null;
    return (
      <span className="ml-1">
        {currentSort.direction === 'asc' ? '↑' : '↓'}
      </span>
    );
  };

  return (
    <div className="w-full">
      {/* Mobile View */}
      <div className="block md:hidden divide-y divide-slate-100">
        {items.map((item, idx) => (
          <div key={`mobile-${item.bes_number}-${idx}`} className="p-4 bg-white hover:bg-slate-50 transition-colors">
            <div className="flex gap-3 items-start">
               <input 
                type="checkbox" 
                checked={!!selectedItems[item.bes_number]}
                onChange={(e) => onSelectionChange(item.bes_number, e.target.checked)}
                className="mt-1 w-5 h-5 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500 cursor-pointer"
              />
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex gap-3">
                    <div>
                      <div className="text-sm font-bold text-slate-900 leading-tight">{item.description}</div>
                    </div>
                  </div>
                </div>
                {selectedItems[item.bes_number] !== undefined && (
                   <div className="mt-2 flex items-center gap-2">
                      <input 
                        type="number" 
                        min="1"
                        value={selectedItems[item.bes_number].quantity}
                        onChange={(e) => onSelectionChange(item.bes_number, true, parseInt(e.target.value) || 1)}
                        className="w-16 px-2 py-1 border border-slate-200 rounded text-xs focus:ring-1 focus:ring-cyan-500 outline-none"
                      />
                      <select
                        value={selectedItems[item.bes_number].unit}
                        onChange={(e) => onSelectionChange(item.bes_number, true, selectedItems[item.bes_number].quantity, e.target.value as OrderUnit)}
                        className="px-2 py-1 border border-slate-200 rounded text-xs bg-white focus:ring-1 focus:ring-cyan-500 outline-none"
                      >
                        <option value="Boxes">Boxes</option>
                        <option value="Cases">Cases</option>
                      </select>
                   </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop/Tablet View */}
      <div className="hidden md:block overflow-visible">
        <table className="min-w-full border-collapse border border-slate-200">
          <thead>
            <tr className="z-20">
              <th className="sticky top-16 px-4 py-4 text-center border border-slate-200 w-12 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">
                <input 
                  type="checkbox" 
                  checked={isAllSelected}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500 cursor-pointer"
                />
              </th>
              <th className="sticky top-16 px-3 py-4 text-center text-[11px] font-bold text-slate-400 uppercase tracking-wider w-12 border border-slate-200 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">#</th>
              <th className="sticky top-16 px-4 py-4 text-center text-[11px] font-bold text-slate-500 uppercase tracking-wider border border-slate-200 w-44 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">ORDER QTY / UNIT</th>
              <th 
                className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-slate-500 uppercase tracking-wider cursor-pointer hover:bg-slate-100 border border-slate-200 transition-colors bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]"
                onClick={() => onSort?.('description')}
              >
                DESCRIPTION {renderSortIcon('description')}
              </th>
              <th className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-slate-500 uppercase tracking-wider border border-slate-200 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">NDC / HCPCS</th>
              <th className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-slate-500 uppercase tracking-wider border border-slate-200 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">STOCK QTY</th>
              <th 
                className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-cyan-600 uppercase tracking-wider cursor-pointer hover:bg-cyan-50 border border-slate-200 transition-colors bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]"
                onClick={() => onSort?.('unit_price')}
              >
                UNIT PRICE {renderSortIcon('unit_price')}
              </th>
              <th className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-slate-500 uppercase tracking-wider border border-slate-200 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">LAST UPDATED</th>
              <th className="sticky top-16 px-6 py-4 text-left text-[11px] font-bold text-slate-500 uppercase tracking-wider border border-slate-200 bg-slate-50 z-20 shadow-[inset_0_-1px_0_rgba(226,232,240,1)]">STATUS</th>
            </tr>
          </thead>
          <tbody className="bg-white">
            {items.map((item, idx) => (
              <tr key={`${item.bes_number}-${idx}`} className={`hover:bg-slate-50/50 transition-colors ${selectedItems[item.bes_number] !== undefined ? 'bg-cyan-50/30' : ''}`}>
                <td className="px-4 py-4 text-center border border-slate-200">
                   <input 
                    type="checkbox" 
                    checked={!!selectedItems[item.bes_number]}
                    onChange={(e) => onSelectionChange(item.bes_number, e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500 cursor-pointer"
                  />
                </td>
                <td className="px-3 py-4 whitespace-nowrap text-center text-[12px] font-bold text-slate-400 border border-slate-200">
                  {idx + 1}
                </td>
                <td className="px-4 py-4 border border-slate-200 text-center">
                  <div className="flex items-center gap-2 justify-center">
                    <input 
                      type="number" 
                      min="1"
                      disabled={selectedItems[item.bes_number] === undefined}
                      value={selectedItems[item.bes_number]?.quantity || 1}
                      onChange={(e) => onSelectionChange(item.bes_number, true, parseInt(e.target.value) || 1)}
                      className={`w-16 px-2 py-1.5 border border-slate-200 rounded text-sm text-center focus:ring-2 focus:ring-cyan-500 outline-none transition-opacity ${selectedItems[item.bes_number] === undefined ? 'opacity-20 cursor-not-allowed' : 'opacity-100'}`}
                    />
                    <select
                      disabled={selectedItems[item.bes_number] === undefined}
                      value={selectedItems[item.bes_number]?.unit || 'Boxes'}
                      onChange={(e) => onSelectionChange(item.bes_number, true, selectedItems[item.bes_number].quantity, e.target.value as OrderUnit)}
                      className={`px-2 py-1.5 border border-slate-200 rounded text-sm bg-white focus:ring-2 focus:ring-cyan-500 outline-none transition-opacity ${selectedItems[item.bes_number] === undefined ? 'opacity-20 cursor-not-allowed' : 'opacity-100'}`}
                    >
                      <option value="Boxes">Boxes</option>
                      <option value="Cases">Cases</option>
                    </select>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <div className="text-sm font-bold text-slate-900 max-w-xs truncate mb-0.5" title={item.description}>{item.description}</div>
                  <div className="text-[11px] text-slate-400 font-medium font-mono">ABC#: {item.bes_number}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <div className="text-sm text-pink-600 font-bold mb-0.5">{item.ndc || '—'}</div>
                  <div className="text-sm text-cyan-500 font-bold">{item.hcpcs || '—'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <div className="text-sm font-bold text-slate-900">{item.quantity ?? '—'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <div className="text-[15px] font-black text-cyan-700 mb-0.5">${item.unit_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                  <div className="text-[11px] text-slate-400 font-bold">per {item.unit}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <div className="text-xs text-slate-500">{item.last_updated ? new Date(item.last_updated).toLocaleDateString() : '—'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap border border-slate-200">
                  <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-tighter ${
                    item.status === 'STOCKED' ? 'bg-emerald-100 text-emerald-600 border border-emerald-200' : 'bg-rose-100 text-rose-600 border border-rose-200'
                  }`}>
                    {item.status === 'STOCKED' ? 'STOCKED' : 'OUT'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default InventoryTable;
