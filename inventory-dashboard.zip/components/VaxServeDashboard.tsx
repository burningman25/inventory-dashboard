
import React, { useState, useMemo } from 'react';
import { VAXSERVE_ITEMS } from '../vaxserveConstants';
import { VaxServeItem, OrderUnit, OrderSelection } from '../types';
import StatsCard from './StatsCard';
import { generateOrderPDF } from '../services/pdfService';

type VaxCategory = 'ALL' | 'VACCINES';

interface VaxServeDashboardProps {
  isDark?: boolean;
}

const VaxServeDashboard: React.FC<VaxServeDashboardProps> = ({ isDark = true }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'IN_STOCK' | 'OUT_OF_STOCK'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<VaxCategory>('ALL');
  const [selectedItems, setSelectedItems] = useState<Record<string, OrderSelection>>({});

  const filteredItems = useMemo(() => {
    return VAXSERVE_ITEMS.filter(item => {
      const matchesSearch = item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.ndc.includes(searchTerm);
      const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
      // VaxServe currently only has Vaccines
      const matchesCategory = categoryFilter === 'ALL' || categoryFilter === 'VACCINES';
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [searchTerm, statusFilter, categoryFilter]);

  const stats = useMemo(() => {
    const total = VAXSERVE_ITEMS.length;
    const stocked = VAXSERVE_ITEMS.filter(i => i.status === 'IN_STOCK').length;
    const oos = VAXSERVE_ITEMS.filter(i => i.status === 'OUT_OF_STOCK').length;
    const atRiskValue = VAXSERVE_ITEMS
      .filter(i => i.status === 'OUT_OF_STOCK')
      .reduce((acc, curr) => acc + curr.price, 0);
    
    return { total, stocked, oos, atRiskValue };
  }, []);

  const handleSelectionChange = (productName: string, isSelected: boolean, quantity?: number, unit?: OrderUnit) => {
    setSelectedItems(prev => {
      const next = { ...prev };
      if (isSelected) {
        next[productName] = {
          quantity: quantity ?? next[productName]?.quantity ?? 1,
          unit: unit ?? next[productName]?.unit ?? 'Packages'
        };
      } else {
        delete next[productName];
      }
      return next;
    });
  };

  const handleClearSelection = () => setSelectedItems({});

  const handleGeneratePDF = () => {
    const orderItems = (Object.entries(selectedItems) as [string, OrderSelection][]).map(([name, selection]) => {
      const item = VAXSERVE_ITEMS.find(i => i.productName === name)!;
      return {
        description: `${item.productName} (${item.description})`,
        quantity: selection.quantity,
        unit: selection.unit,
        unitPrice: item.price,
        total: selection.quantity * item.price
      };
    });
    generateOrderPDF('VaxServe', orderItems);
  };

  const selectedCount = Object.keys(selectedItems).length;
  const estimatedTotal = (Object.entries(selectedItems) as [string, OrderSelection][]).reduce((sum, [name, selection]) => {
    const item = VAXSERVE_ITEMS.find(i => i.productName === name);
    if (!item) return sum;
    return sum + (item.price * selection.quantity);
  }, 0);

  const getPriceColor = (price: number) => {
    if (price < 100) return isDark ? 'text-[#22C55E]' : 'text-emerald-600';
    if (price < 1000) return isDark ? 'text-[#F59E0B]' : 'text-amber-600';
    return isDark ? 'text-[#EF4444]' : 'text-rose-600';
  };

  const colors = {
    bg: isDark ? 'bg-[#0B1220]' : 'bg-[#F8FAFC]',
    panel: isDark ? 'bg-[#0F172A]' : 'bg-[#FFFFFF]',
    card: isDark ? 'bg-[#1E293B]' : 'bg-[#FFFFFF]',
    textPrimary: isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]',
    textSecondary: isDark ? 'text-[#CBD5E1]' : 'text-[#64748B]',
    border: isDark ? 'border-[#334155]' : 'border-slate-200'
  };

  return (
    <div className={`space-y-8 pb-32 transition-colors duration-500 ${colors.bg} min-h-full`}>
      {/* VaxServe Specific Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div className="flex flex-col gap-1">
          <h2 className={`text-3xl font-black transition-colors duration-500 ${colors.textPrimary} tracking-tighter uppercase`}>Vaccine Inventory Dashboard</h2>
          <p className={`transition-colors duration-500 ${colors.textSecondary} text-sm font-medium tracking-wide uppercase`}>Real-time vaccine procurement</p>
        </div>
        <div className={`flex flex-col items-end px-4 py-2 rounded-xl border ${colors.border} ${colors.panel} shadow-sm`}>
           <span className={`text-[10px] font-black tracking-[0.2em] uppercase transition-colors duration-500 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Account Access</span>
           <span className={`text-sm font-black tracking-tight ${colors.textPrimary}`}>I D CONSULTANTS INC — <span className="text-violet-500">0100334865</span></span>
           <a 
            href="https://www.vaxserve.com/vax/en/USD/search/yellow" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[10px] font-bold text-violet-400 hover:text-violet-300 mt-1 flex items-center gap-1 uppercase tracking-wider transition-colors"
           >
             VaxServe Portal
             <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
           </a>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Items" 
          value={stats.total} 
          isDark={isDark} color={isDark ? "bg-[#1F2937] text-[#CBD5E1]" : "bg-slate-100 text-slate-600"}
          icon={<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>}
        />
        <StatsCard 
          title="Ready" 
          value={stats.stocked} 
          isDark={isDark} color="bg-[#22C55E]/10 text-[#22C55E]"
          icon={<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>}
        />
        <StatsCard 
          title="Blocked" 
          value={stats.oos} 
          isDark={isDark} color="bg-[#EF4444]/10 text-[#EF4444]"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>}
        />
        <StatsCard 
          title="$ At Risk" 
          value={`$${stats.atRiskValue.toLocaleString()}`} 
          isDark={isDark} color="bg-[#F59E0B]/10 text-[#F59E0B]"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" strokeWidth="2"/><circle cx="12" cy="12" r="4" strokeWidth="2"/></svg>}
        />
      </div>

      <div className="space-y-4">
        <div className={`flex flex-col md:flex-row gap-4 items-center justify-between p-4 rounded-xl border transition-all duration-500 ${colors.panel} ${isDark ? 'border-[#334155]' : 'border-slate-200'}`}>
          <div className="relative w-full md:w-96">
            <input 
              type="text" 
              placeholder="Search Vaccines, NDCs, Manufacturers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full border ${isDark ? 'bg-[#111827] border-[#334155] text-[#F9FAFB] placeholder-[#6B7280]' : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'} pl-10 pr-4 py-2.5 rounded-lg text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all`}
            />
            <svg className={`w-5 h-5 absolute left-3 top-2.5 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            {['ALL', 'IN_STOCK', 'OUT_OF_STOCK'].map((f) => (
              <button
                key={f}
                onClick={() => setStatusFilter(f as any)}
                className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all border ${
                  statusFilter === f 
                    ? (isDark ? 'bg-violet-600 border-violet-600 text-white shadow-lg shadow-violet-500/20' : 'bg-violet-600 border-violet-600 text-white shadow-md')
                    : (isDark ? 'bg-[#111827] border-[#334155] text-[#CBD5E1] hover:text-[#F9FAFB]' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50')
                }`}
              >
                {f.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Section */}
        <div className="flex flex-wrap items-center gap-2 px-1">
          {(['ALL', 'VACCINES'] as VaxCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border ${
                categoryFilter === cat
                  ? (isDark ? 'bg-violet-500/10 text-violet-400 border-violet-500/40 shadow-[0_0_15px_rgba(139,92,246,0.1)]' : 'bg-violet-600 text-white border-violet-600 shadow-md')
                  : (isDark ? 'bg-[#111827] border-[#334155] text-slate-400 hover:border-slate-500 hover:text-slate-300' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50')
              }`}
            >
              {cat} <span className={`ml-1 opacity-50 font-mono`}>({cat === 'ALL' ? VAXSERVE_ITEMS.length : VAXSERVE_ITEMS.length})</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div 
            key={item.productName} 
            className={`group relative rounded-xl border-2 transition-all duration-300 hover:-translate-y-1 ${
              isDark 
                ? `bg-[#1E293B] shadow-xl shadow-black/40 ${selectedItems[item.productName] ? 'border-violet-500' : 'border-[#334155] hover:border-violet-500/50'}`
                : `bg-white border-slate-200 shadow-sm hover:shadow-md ${selectedItems[item.productName] ? 'border-violet-500 shadow-violet-50' : 'border-slate-100'}`
            }`}
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4 gap-4">
                <div className="flex-1">
                   <h3 className={`text-xl font-black leading-tight uppercase group-hover:text-violet-400 transition-colors ${colors.textPrimary}`}>
                    {item.productName}
                  </h3>
                  <div className="mt-1">
                    <span className={`text-xs font-bold ${colors.textSecondary}`}>{item.description}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <span className={`text-[9px] font-mono font-black px-2 py-0.5 rounded border ${isDark ? 'text-[#94A3B8] bg-black/20 border-[#334155]' : 'text-slate-500 bg-slate-50 border-slate-200'}`}>NDC: {item.ndc}</span>
                    <span className={`text-[9px] font-mono font-black px-2 py-0.5 rounded border ${isDark ? 'text-violet-400 bg-violet-500/5 border-violet-500/20' : 'text-violet-600 bg-violet-50 border-violet-100'}`}>ITEM: {item.itemNumber}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <input 
                    type="checkbox" 
                    checked={!!selectedItems[item.productName]}
                    onChange={(e) => handleSelectionChange(item.productName, e.target.checked)}
                    className={`w-5 h-5 rounded cursor-pointer ${isDark ? 'border-[#334155] bg-[#0F172A] text-violet-500 focus:ring-violet-500' : 'border-slate-300 text-violet-600 focus:ring-violet-500'}`}
                  />
                  <span className={`px-2.5 py-0.5 text-[9px] font-black rounded border tracking-widest transition-all ${
                    item.status === 'IN_STOCK' 
                      ? (isDark ? 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/30 glow-pill' : 'bg-emerald-100 text-emerald-700 border-emerald-200')
                      : (isDark ? 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/30' : 'bg-rose-100 text-rose-700 border-rose-200')
                  }`}>
                    {item.status === 'IN_STOCK' ? 'IN STOCK' : 'OUT'}
                  </span>
                </div>
              </div>

              <div className={`p-3 rounded-lg text-[10px] leading-relaxed mb-4 ${isDark ? 'bg-black/20 text-[#94A3B8]' : 'bg-slate-50 text-slate-500'}`}>
                {item.details}
              </div>

              <div className={`flex items-center justify-between py-4 border-y my-4 transition-colors duration-500 ${isDark ? 'border-[#334155]' : 'border-slate-100'}`}>
                <div className="flex flex-col">
                  <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#94A3B8]' : 'text-slate-400'}`}>Doses</span>
                  <span className={`text-xs font-bold font-mono ${isDark ? 'text-[#CBD5E1]' : 'text-slate-600'}`}>{item.doseCount} Doses / Package</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#94A3B8]' : 'text-slate-400'}`}>Unit Price</span>
                  <span className={`text-2xl font-black tracking-tighter ${getPriceColor(item.price)}`}>
                    ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className={`transition-all duration-300 ${selectedItems[item.productName] ? 'opacity-100' : 'opacity-30 grayscale pointer-events-none'}`}>
                <div className="flex items-center gap-3">
                  <div className={`flex-1 flex items-center rounded-lg p-1 border transition-colors duration-500 ${isDark ? 'bg-[#0F172A] border-[#334155]' : 'bg-white border-slate-200'}`}>
                    <input 
                      type="number" 
                      min="1"
                      value={selectedItems[item.productName]?.quantity || 1}
                      onChange={(e) => handleSelectionChange(item.productName, true, parseInt(e.target.value) || 1)}
                      className={`w-full bg-transparent text-center font-black text-sm outline-none px-2 ${isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]'}`}
                    />
                  </div>
                  <div className="flex-1">
                    <select
                      value={selectedItems[item.productName]?.unit || 'Packages'}
                      onChange={(e) => handleSelectionChange(item.productName, true, selectedItems[item.productName]?.quantity, e.target.value as OrderUnit)}
                      className={`w-full border text-xs font-black p-2 rounded-lg outline-none cursor-pointer uppercase tracking-widest transition-colors duration-500 ${isDark ? 'bg-[#0F172A] border-[#334155] text-[#F9FAFB]' : 'bg-white border-slate-200 text-slate-700'}`}
                    >
                      <option value="Packages">Packages</option>
                      <option value="Cases">Cases</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Support Footer */}
      <div className={`mt-12 p-6 rounded-2xl border transition-all duration-500 ${colors.panel} ${colors.border}`}>
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-violet-500/10 rounded-xl">
              <svg className="w-6 h-6 text-violet-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            </div>
            <div>
              <h4 className={`text-sm font-black uppercase tracking-widest ${colors.textPrimary}`}>VaxServe Support</h4>
              <p className={`text-xs font-medium ${colors.textSecondary}`}>Dedicated vaccine inventory assistance</p>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-4 sm:gap-8">
            <div className="flex flex-col items-center md:items-end">
              <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Telephone</span>
              <a href="tel:1-800-752-9338" className={`text-sm font-black hover:text-violet-400 transition-colors ${colors.textPrimary}`}>1-800-752-9338</a>
            </div>
            <div className="flex flex-col items-center md:items-end">
              <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Direct Email</span>
              <a href="mailto:VaxServe@vaxserve.com" className={`text-sm font-black hover:text-violet-400 transition-colors ${colors.textPrimary}`}>VaxServe@vaxserve.com</a>
            </div>
          </div>
        </div>
      </div>

      {/* Procurement Bar */}
      {selectedCount > 0 && (
        <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 w-[95%] max-w-5xl backdrop-blur-md shadow-2xl rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-6 z-[100] border-2 transition-all duration-500 ${isDark ? 'bg-[#0F172A]/98 border-[#F97316]/30 shadow-black' : 'bg-white border-orange-100'}`}>
          <div className="flex items-center gap-10">
             <div className="flex flex-col">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Batch Size</span>
              <div className="flex items-center gap-3">
                <span className={`text-xl font-black leading-none ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{selectedCount} <span className="text-[#F97316] text-sm uppercase font-black">vaccines selected</span></span>
                <button 
                  onClick={handleClearSelection}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${isDark ? 'text-slate-400 hover:text-white hover:bg-white/5' : 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'}`}
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  Clear
                </button>
              </div>
            </div>
            <div className={`w-px h-12 ${isDark ? 'bg-[#1F2937]' : 'bg-slate-100'}`}></div>
            <div className="flex flex-col">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Capital Expenditure</span>
              <span className={`text-3xl font-black leading-none ${isDark ? 'text-[#F9FAFB]' : 'text-orange-600'}`}>
                <span className="text-xl mr-1 opacity-50">$</span>
                {estimatedTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
          <button 
            onClick={handleGeneratePDF}
            className={`w-full md:w-auto px-10 py-4 font-black rounded-xl transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-sm bg-[#F97316] text-[#0B1220] hover:bg-orange-400 shadow-orange-500/40`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            Finalize Procurement
          </button>
        </div>
      )}

      <style>{`
        .glow-pill {
          box-shadow: 0 0 10px rgba(34,197,94,0.15);
          animation: pulse-glow 3s infinite ease-in-out;
        }
        @keyframes pulse-glow {
          0% { box-shadow: 0 0 8px rgba(34,197,94,0.1); }
          50% { box-shadow: 0 0 18px rgba(34,197,94,0.4); border-color: rgba(34,197,94,0.5); }
          100% { box-shadow: 0 0 8px rgba(34,197,94,0.1); }
        }
      `}</style>
    </div>
  );
};

export default VaxServeDashboard;
