
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Printer, Trash2, Plus, Minus, FileText, Calendar, User, Package, CheckCircle2, AlertCircle, Search, Filter, ArrowUpRight, ChevronRight, ShoppingCart } from 'lucide-react';

interface OrderItem {
  desc: string;
  status: 'STOCKED' | 'IN_STOCK' | 'OUT_OF_STOCK';
  box: string;
  caseQty: number | null;
}

const CENCORA: OrderItem[] = [
  { desc: "AMIKACIN SUL 1 GM SDV 10X4 ML",                          status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "AMPICILLIN 2GM VIAL 10",                                  status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "AZTREONAM 1 GM SDV 10",                                   status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "AZTREONAM 2 GM SDV 10",                                   status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "BD Insyte IV Catheter Shield 22GX1\" 50CT Blue Vialon",   status: "STOCKED",      box: "Box/50",  caseQty: null },
  { desc: "BD Insyte IV Catheter Shielded 24GX3/4\" 50CT Yellow",    status: "STOCKED",      box: "Box/50",  caseQty: null },
  { desc: "BD Posiflush Saline 0.9% Syringe 30X10ML",                status: "STOCKED",      box: "Box/30",  caseQty: null },
  { desc: "BICILLIN LA 1200 MU PFS 10X2 ML",                         status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "CEFAZOLIN 10 GM VL 10",                                   status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "CEFAZOLIN 1GM VL 25",                                     status: "STOCKED",      box: "Box/25",  caseQty: 25 },
  { desc: "CEFOXITIN 1 GM VL 25",                                    status: "STOCKED",      box: "Box/25",  caseQty: 25 },
  { desc: "DIPHENHYDRAMINE HCL 50 MG VL 25X1 ML",                   status: "STOCKED",      box: "Box/25",  caseQty: 25 },
  { desc: "EPINEPHRINE 1 MG-ML AMP 10X1 ML",                        status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "PFIZERPEN 20 MMU VL",                                     status: "STOCKED",      box: "Each",    caseQty: null },
  { desc: "PIPERACIL-TAZOBACTAM 4.5 GM SDV 10",                     status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "Povidone Iodine Swabs 25X3BX Antiseptic 10%",             status: "STOCKED",      box: "Pack/75", caseQty: null },
  { desc: "Sodium Chl 0.9% Bag 10X1000 ML IV",                      status: "STOCKED",      box: "Case/10", caseQty: 10 },
  { desc: "Sodium Chloride 0.9% Bag 24X500 ML",                     status: "STOCKED",      box: "Case/24", caseQty: 24 },
  { desc: "TIGECYCLINE 50 MG PWD SDV 10",                          status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "VANCOMYCIN HCL 1 GM SDV 10 NVP",                         status: "STOCKED",      box: "Box/10",  caseQty: 10 },
  { desc: "XERAVA 100 MG SDV 12",                                    status: "STOCKED",      box: "Box/12",  caseQty: 12 },
];

const PINNACLE: OrderItem[] = [
  { desc: "Water Sterile PF 20mL",                    status: "IN_STOCK",    box: "Box/25",       caseQty: null },
  { desc: "Amikacin 500mg 2mL",                        status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Ampicillin 1gm",                            status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Cefepime 2gm",                              status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Daptomycin 500mg",                          status: "IN_STOCK",    box: "Each",         caseQty: null },
  { desc: "Ertapenem 1gm",                             status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Meropenem 1gm",                             status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Piperacillin Tazobactam 3.375gm",           status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Vancomycin 1gm",                            status: "IN_STOCK",    box: "Box/10",       caseQty: null },
  { desc: "Bandage Cohesive 2\" Multi-Color",          status: "IN_STOCK",    box: "Box/36",       caseQty: null },
  { desc: "Spandage Tubular LF Wrap Size 6",           status: "IN_STOCK",    box: "Each",         caseQty: null },
  { desc: "Adaptic Dressing 3\" x 3\"",               status: "IN_STOCK",    box: "Box/50",       caseQty: null },
  { desc: "Tegaderm Transparent 2.75\" x 2.375\"",    status: "IN_STOCK",    box: "Box/100",      caseQty: null },
  { desc: "Tegaderm Transparent 4\" x 4.75\"",        status: "IN_STOCK",    box: "Box/50",       caseQty: null },
  { desc: "Gauze 2\" x 2\" 8-Ply NS",                status: "IN_STOCK",    box: "Bag/200",      caseQty: null },
  { desc: "Alcohol Prep Pads ST Medium",               status: "IN_STOCK",    box: "Box/200",      caseQty: null },
  { desc: "Super Sani-Cloth Germicidal Wipes Large",   status: "IN_STOCK",    box: "Canister/160", caseQty: null },
  { desc: "IV Extension Set 7\" Minibore",             status: "IN_STOCK",    box: "Box/50",       caseQty: null },
  { desc: "Syringe Cap ST Blue",                       status: "IN_STOCK",    box: "Box",          caseQty: 2000 },
  { desc: "Ultrasite NF Connector",                    status: "IN_STOCK",    box: "Box/100",      caseQty: null },
  { desc: "Huber Needle 8\" Set 22g x 3/4\"",         status: "IN_STOCK",    box: "Box",          caseQty: 100 },
  { desc: "Huber Needle 8\" Set 22g x 1\"",           status: "IN_STOCK",    box: "Box",          caseQty: 100 },
];

const VAXSERVE: OrderItem[] = [
  { desc: "YF-VAX® — Yellow Fever Vaccine (5-dose kit)", status: "IN_STOCK", box: "Kit/5", caseQty: null },
];

interface OrderState {
  [key: string]: {
    qty: number;
    unit: 'box' | 'case';
  };
}

interface SupplyOrderSheetProps {
  isDark: boolean;
}

const SupplyOrderSheet: React.FC<SupplyOrderSheetProps> = ({ isDark }) => {
  const [orderState, setOrderState] = useState<OrderState>(() => {
    const saved = localStorage.getItem('supply_order_state');
    return saved ? JSON.parse(saved) : {};
  });
  const [orderDate, setOrderDate] = useState(() => {
    const saved = localStorage.getItem('supply_order_date');
    return saved || new Date().toISOString().split('T')[0];
  });
  const [requestedBy, setRequestedBy] = useState(() => {
    const saved = localStorage.getItem('supply_order_requested_by');
    return saved || '';
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [showSelectedOnly, setShowSelectedOnly] = useState(false);
  const [hideOutOfStock, setHideOutOfStock] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    localStorage.setItem('supply_order_state', JSON.stringify(orderState));
  }, [orderState]);

  useEffect(() => {
    localStorage.setItem('supply_order_date', orderDate);
  }, [orderDate]);

  useEffect(() => {
    localStorage.setItem('supply_order_requested_by', requestedBy);
  }, [requestedBy]);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const filterItems = (items: OrderItem[], prefix: string) => {
    return items
      .map((item, i) => ({ ...item, originalIndex: i }))
      .filter((item) => {
        const id = `${prefix}-${item.originalIndex}`;
        const state = orderState[id];
        const matchesSearch = item.desc.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesSelected = !showSelectedOnly || (state && state.qty > 0);
        const matchesStock = !hideOutOfStock || (item.status === 'STOCKED' || item.status === 'IN_STOCK');
        return matchesSearch && matchesSelected && matchesStock;
      });
  };

  const filteredCencora = useMemo(() => filterItems(CENCORA, 'c'), [searchTerm, showSelectedOnly, orderState, hideOutOfStock]);
  const filteredPinnacle = useMemo(() => filterItems(PINNACLE, 'p'), [searchTerm, showSelectedOnly, orderState, hideOutOfStock]);
  const filteredVaxServe = useMemo(() => filterItems(VAXSERVE, 'v'), [searchTerm, showSelectedOnly, orderState, hideOutOfStock]);

  const updateQty = (id: string, delta: number) => {
    setOrderState(prev => {
      const current = prev[id] || { qty: 0, unit: 'box' };
      const newQty = Math.max(0, current.qty + delta);
      return {
        ...prev,
        [id]: { ...current, qty: newQty }
      };
    });
  };

  const setUnit = (id: string, unit: 'box' | 'case') => {
    setOrderState(prev => ({
      ...prev,
      [id]: { ...(prev[id] || { qty: 0 }), unit }
    }));
  };

  const clearAll = () => {
    if (totalItems > 0) {
      if (window.confirm('Are you sure you want to clear all quantities? This cannot be undone.')) {
        setOrderState({});
        localStorage.removeItem('supply_order_state');
      }
    }
  };

  const totalItems = (Object.values(orderState) as { qty: number; unit: 'box' | 'case' }[]).filter(item => item.qty > 0).length;
  const cencoraCount = Object.keys(orderState).filter(id => id.startsWith('c-') && (orderState[id] as { qty: number }).qty > 0).length;
  const pinnacleCount = Object.keys(orderState).filter(id => id.startsWith('p-') && (orderState[id] as { qty: number }).qty > 0).length;
  const vaxServeCount = Object.keys(orderState).filter(id => id.startsWith('v-') && (orderState[id] as { qty: number }).qty > 0).length;

  const handlePrint = () => {
    const printDate = new Date().toLocaleDateString();
    
    const buildPrintRows = (items: OrderItem[], prefix: string) => {
      return items.map((item, i) => {
        const id = `${prefix}-${i}`;
        const state = orderState[id];
        if (!state || state.qty === 0) return '';
        
        const unitLabel = (state.unit === 'case' && item.caseQty)
          ? `Case of ${item.caseQty}`
          : item.box;
        const isIn = item.status === 'STOCKED' || item.status === 'IN_STOCK';
        
        const statusText = isIn ? 'IN STOCK' : 'OUT OF STOCK';
        return `
          <tr>
            <td style="padding:7px 10px;border-bottom:1px solid #E2DED6">${item.desc}</td>
            <td style="padding:7px 10px;border-bottom:1px solid #E2DED6">
              <span style="font-size:7px;font-weight:900;letter-spacing:.15em;text-transform:uppercase;padding:3px 8px;border-radius:100px;border:1px solid;display:inline-flex;align-items:center;gap:4px;
                ${isIn ? 'color:#065F46;background:#ECFDF5;border-color:#A7F3D0' : 'color:#991B1B;background:#FEF2F2;border-color:#FECACA'}">
                <span style="width:4px;height:4px;border-radius:50%;background:currentColor;display:inline-block"></span>
                ${statusText}
              </span>
            </td>
            <td style="padding:7px 10px;border-bottom:1px solid #E2DED6;text-align:center;font-family:monospace;font-weight:600">${state.qty}</td>
            <td style="padding:7px 10px;border-bottom:1px solid #E2DED6;font-family:monospace;font-size:11px;color:#888">${unitLabel}</td>
          </tr>
        `;
      }).join('');
    };

    const vendorTable = (name: string, color: string, items: OrderItem[], prefix: string) => {
      const rows = buildPrintRows(items, prefix);
      if (!rows.trim()) return '';
      
      return `
        <div style="margin-bottom:28px;page-break-inside:avoid">
          <div style="background:${color}15;border:1.5px solid ${color};border-bottom:none;border-radius:6px 6px 0 0;
            padding:8px 14px;display:flex;align-items:center;gap:10px">
            <div style="width:9px;height:9px;border-radius:50%;background:${color}"></div>
            <span style="font-family:'Syne',sans-serif;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:${color}">${name}</span>
          </div>
          <table style="width:100%;border-collapse:collapse;border:1.5px solid #E2DED6;border-top:none;border-radius:0 0 6px 6px;background:#fff">
            <thead>
              <tr style="background:#F9F8F6">
                <th style="padding:7px 10px;text-align:left;font-family:monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#888;border-bottom:1.5px solid #E2DED6;width:52%">Item Description</th>
                <th style="padding:7px 10px;text-align:left;font-family:monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#888;border-bottom:1.5px solid #E2DED6">Stock</th>
                <th style="padding:7px 10px;text-align:center;font-family:monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#888;border-bottom:1.5px solid #E2DED6">Qty</th>
                <th style="padding:7px 10px;text-align:left;font-family:monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#888;border-bottom:1.5px solid #E2DED6">Order Unit</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    };

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>ID Consultants Inc. — Purchase Order</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', sans-serif; font-size: 12px; color: #1A1A1A; background: #fff; padding: 32px; }
    @media print {
      body { padding: 18px; }
      @page { margin: 15mm; }
    }
  </style>
</head>
<body>
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:24px;padding-bottom:18px;border-bottom:2px solid #1A1A1A">
    <div>
      <div style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.15em;text-transform:uppercase;color:#888;margin-bottom:4px">Purchase Order</div>
      <div style="font-family:'Syne',sans-serif;font-size:26px;font-weight:800;letter-spacing:-.5px">ID Consultants Inc.</div>
    </div>
    <div style="text-align:right;font-family:'DM Mono',monospace;font-size:11px;color:#444;line-height:2">
      <div><span style="color:#888;font-size:9px;letter-spacing:.12em;text-transform:uppercase">Order Date</span><br/><strong>${orderDate || '—'}</strong></div>
      ${requestedBy ? `<div style="margin-top:6px"><span style="color:#888;font-size:9px;letter-spacing:.12em;text-transform:uppercase">Requested By</span><br/><strong>${requestedBy}</strong></div>` : ''}
    </div>
  </div>

  ${vendorTable('Cencora', '#16A34A', CENCORA, 'c')}
  ${vendorTable('Pinnacle Distribution', '#2563EB', PINNACLE, 'p')}
  ${vendorTable('VaxServe', '#7C3AED', VAXSERVE, 'v')}

  <div style="margin-top:32px;padding-top:14px;border-top:1px solid #ccc;font-family:'DM Mono',monospace;font-size:9px;color:#aaa">
    ID Consultants Inc. &nbsp;·&nbsp; Infusion Supply Order &nbsp;·&nbsp; Printed ${printDate} &nbsp;·&nbsp; Draft — for internal procurement reference only.
  </div>
</body>
</html>`;

    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) {
      alert('Please allow pop-ups for this page, then try again.');
      return;
    }
    win.document.write(html);
    win.document.close();
    
    let printed = false;
    const triggerPrint = () => {
      if (printed) return;
      printed = true;
      win.focus();
      win.print();
    };

    win.onload = triggerPrint;
    setTimeout(triggerPrint, 800);
  };

  const renderTable = (items: (OrderItem & { originalIndex: number })[], prefix: string, vendorName: string, color: string) => (
    <div className={`mb-12 overflow-hidden rounded-2xl border ${isDark ? 'border-[#1F2937] bg-[#0F172A]' : 'border-slate-200 bg-white shadow-sm'}`}>
      <div className={`flex items-center gap-3 px-6 py-4 border-b ${isDark ? 'border-[#1F2937] bg-[#111827]' : 'border-slate-100 bg-slate-50/50'}`}>
        <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
        <h2 className={`text-sm font-black uppercase tracking-widest font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{vendorName}</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="sticky top-[148px] z-30">
            <tr className={isDark ? 'bg-[#111827]' : 'bg-slate-50/30'}>
              <th className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Item Description</th>
              <th className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Stock</th>
              <th className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest text-center font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Qty</th>
              <th className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Order Unit</th>
              <th className={`px-6 py-3 text-[10px] font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Pack Size</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${isDark ? 'divide-[#1F2937]' : 'divide-slate-100'}`}>
            {items.map((item) => {
              const id = `${prefix}-${item.originalIndex}`;
              const state = orderState[id] || { qty: 0, unit: 'box' };
              const isIn = item.status === 'STOCKED' || item.status === 'IN_STOCK';
              
              return (
                <tr key={id} className={`transition-all duration-200 ${
                  state.qty > 0 
                    ? (isDark ? 'bg-emerald-500/5 border-l-4 border-l-emerald-500' : 'bg-emerald-50/50 border-l-4 border-l-emerald-500')
                    : (isDark ? 'hover:bg-[#111827] border-l-4 border-l-transparent' : 'hover:bg-slate-50/50 border-l-4 border-l-transparent')
                }`}>
                  <td className="px-6 py-4">
                    <div className={`text-sm font-bold leading-tight ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{item.desc}</div>
                    {state.qty > 0 && (
                      <div className="flex items-center gap-1 mt-1 text-[10px] font-black uppercase tracking-widest text-emerald-500">
                        <ShoppingCart className="w-3 h-3" /> Added to Order
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.15em] border shadow-sm transition-all duration-300 ${
                      isIn 
                        ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-emerald-50 text-emerald-700 border-emerald-200')
                        : (isDark ? 'bg-rose-500/10 text-rose-400 border-rose-500/20 animate-pulse' : 'bg-rose-50 text-rose-700 border-rose-200 shadow-rose-100')
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${isIn ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                      {isIn ? 'IN STOCK' : 'OUT OF STOCK'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className={`flex items-center justify-center gap-1 p-1 rounded-xl border ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-200'}`}>
                      <button 
                        onClick={() => updateQty(id, -1)}
                        className={`p-1 rounded-lg transition-colors ${isDark ? 'hover:bg-[#1F2937] text-[#94A3B8]' : 'hover:bg-white text-slate-400 shadow-sm'}`}
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <input 
                        type="number"
                        value={state.qty}
                        onChange={(e) => setOrderState(prev => ({ ...prev, [id]: { ...state, qty: Math.max(0, parseInt(e.target.value) || 0) } }))}
                        className={`w-12 text-center bg-transparent text-sm font-black font-mono focus:outline-none ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}
                      />
                      <button 
                        onClick={() => updateQty(id, 1)}
                        className={`p-1 rounded-lg transition-colors ${isDark ? 'hover:bg-[#1F2937] text-[#94A3B8]' : 'hover:bg-white text-slate-400 shadow-sm'}`}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex gap-1 mt-2 justify-center">
                      <button 
                        onClick={() => updateQty(id, 5)}
                        className={`px-2 py-0.5 rounded text-[8px] font-black border transition-all ${isDark ? 'border-[#1F2937] text-[#6B7280] hover:text-[#F9FAFB] hover:bg-[#1F2937]' : 'border-slate-100 text-slate-400 hover:text-slate-900 hover:bg-slate-50'}`}
                      >
                        +5
                      </button>
                      <button 
                        onClick={() => updateQty(id, 10)}
                        className={`px-2 py-0.5 rounded text-[8px] font-black border transition-all ${isDark ? 'border-[#1F2937] text-[#6B7280] hover:text-[#F9FAFB] hover:bg-[#1F2937]' : 'border-slate-100 text-slate-400 hover:text-slate-900 hover:bg-slate-50'}`}
                      >
                        +10
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {item.caseQty ? (
                      <div className={`inline-flex p-1 rounded-xl border ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-200'}`}>
                        <button 
                          onClick={() => setUnit(id, 'box')}
                          className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all font-mono ${
                            state.unit === 'box' 
                              ? (isDark ? 'bg-[#1F2937] text-[#F9FAFB]' : 'bg-white text-slate-900 shadow-sm')
                              : 'text-slate-500'
                          }`}
                        >
                          Box
                        </button>
                        <button 
                          onClick={() => setUnit(id, 'case')}
                          className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all font-mono ${
                            state.unit === 'case' 
                              ? (isDark ? 'bg-[#1F2937] text-[#F9FAFB]' : 'bg-white text-slate-900 shadow-sm')
                              : 'text-slate-500'
                          }`}
                        >
                          Case
                        </button>
                      </div>
                    ) : (
                      <span className={`text-xs font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>{item.box}</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-xs font-mono font-bold ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                      {state.unit === 'case' && item.caseQty ? `Case of ${item.caseQty}` : item.box}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto pb-32">
      {/* Quick Navigation & Search */}
      <div className="sticky top-20 z-40 mb-8">
        <div className={`p-4 rounded-2xl border shadow-lg backdrop-blur-md ${
          isDark ? 'bg-[#0F172A]/80 border-[#1F2937]' : 'bg-white/80 border-slate-200'
        }`}>
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`} />
              <input 
                type="text"
                placeholder="Search items across all vendors..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full pl-11 pr-4 py-3 rounded-xl text-sm font-bold focus:outline-none border transition-all ${
                  isDark ? 'bg-[#111827] border-[#1F2937] text-[#F9FAFB] focus:border-emerald-500' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-emerald-500'
                }`}
              />
            </div>
            
            <div className="flex items-center gap-2 w-full md:w-auto">
              <button 
                onClick={() => setShowSelectedOnly(!showSelectedOnly)}
                className={`flex items-center gap-2 px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                  showSelectedOnly 
                    ? 'bg-emerald-600 text-white border-emerald-600' 
                    : (isDark ? 'bg-[#111827] border-[#1F2937] text-[#6B7280] hover:text-[#F9FAFB]' : 'bg-slate-50 border-slate-100 text-slate-500 hover:text-slate-900')
                }`}
              >
                <Filter className="w-3 h-3" />
                {showSelectedOnly ? 'Showing Selected' : 'Show Selected Only'}
              </button>

              <button 
                onClick={() => setHideOutOfStock(!hideOutOfStock)}
                className={`flex items-center gap-2 px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                  hideOutOfStock 
                    ? 'bg-rose-600 text-white border-rose-600' 
                    : (isDark ? 'bg-[#111827] border-[#1F2937] text-[#6B7280] hover:text-[#F9FAFB]' : 'bg-slate-50 border-slate-100 text-slate-500 hover:text-slate-900')
                }`}
              >
                <AlertCircle className="w-3 h-3" />
                {hideOutOfStock ? 'Hiding Out of Stock' : 'Hide Out of Stock'}
              </button>
              
              <div className={`hidden lg:flex items-center gap-1 p-1 rounded-xl border ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-100'}`}>
                <a href="#vendor-cencora" className={`px-3 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-emerald-500/10 hover:text-emerald-500 transition-all ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Cencora</a>
                <a href="#vendor-pinnacle" className={`px-3 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-blue-500/10 hover:text-blue-500 transition-all ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Pinnacle</a>
                <a href="#vendor-vaxserve" className={`px-3 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-violet-500/10 hover:text-violet-500 transition-all ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>VaxServe</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Header Section */}
      <div className={`mb-12 p-8 rounded-3xl border ${isDark ? 'bg-[#0F172A] border-[#1F2937]' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="flex flex-col md:flex-row justify-between items-start gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className={`p-3 rounded-2xl ${isDark ? 'bg-emerald-500/10 text-emerald-400' : 'bg-emerald-50 text-emerald-600'}`}>
                <FileText className="w-8 h-8" />
              </div>
              <div>
                <span className={`text-[10px] font-black uppercase tracking-[0.3em] font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Purchase Order</span>
                <h1 className={`text-3xl font-black tracking-tighter font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>ID Consultants Inc.</h1>
              </div>
            </div>
            <p className={`text-sm font-medium max-w-md ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
              Generate professional supply order sheets for internal procurement. Select items and quantities across multiple vendors.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full md:w-auto">
            <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-100'}`}>
              <label className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest mb-2 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                <Calendar className="w-3 h-3" /> Order Date
              </label>
              <input 
                type="date"
                value={orderDate}
                onChange={(e) => setOrderDate(e.target.value)}
                className={`w-full bg-transparent text-sm font-black focus:outline-none font-mono ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}
              />
            </div>
            <div className={`p-4 rounded-2xl border ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-100'}`}>
              <label className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest mb-2 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                <User className="w-3 h-3" /> Requested By
              </label>
              <input 
                type="text"
                value={requestedBy}
                onChange={(e) => setRequestedBy(e.target.value)}
                placeholder="Name / Initials"
                className={`w-full bg-transparent text-sm font-black placeholder:text-slate-600 focus:outline-none font-mono ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tables */}
      <div id="vendor-cencora">
        {filteredCencora.length > 0 ? renderTable(filteredCencora, 'c', 'Cencora', '#16A34A') : (
          searchTerm && <div className="mb-8 p-8 text-center rounded-2xl border border-dashed border-slate-700 text-slate-500 font-bold">No Cencora items match your search</div>
        )}
      </div>
      
      <div id="vendor-pinnacle">
        {filteredPinnacle.length > 0 ? renderTable(filteredPinnacle, 'p', 'Pinnacle Distribution', '#2563EB') : (
          searchTerm && <div className="mb-8 p-8 text-center rounded-2xl border border-dashed border-slate-700 text-slate-500 font-bold">No Pinnacle items match your search</div>
        )}
      </div>
      
      <div id="vendor-vaxserve">
        {filteredVaxServe.length > 0 ? renderTable(filteredVaxServe, 'v', 'VaxServe', '#7C3AED') : (
          searchTerm && <div className="mb-8 p-8 text-center rounded-2xl border border-dashed border-slate-700 text-slate-500 font-bold">No VaxServe items match your search</div>
        )}
      </div>

      {totalItems === 0 && searchTerm && filteredCencora.length === 0 && filteredPinnacle.length === 0 && filteredVaxServe.length === 0 && (
        <div className={`p-12 text-center rounded-3xl border border-dashed ${isDark ? 'border-[#1F2937] bg-[#0F172A]' : 'border-slate-200 bg-white'}`}>
          <Search className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-[#1F2937]' : 'text-slate-200'}`} />
          <h3 className={`text-xl font-black mb-2 ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>No items found</h3>
          <p className={`text-sm ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Try adjusting your search or filters to find what you're looking for.</p>
          <button 
            onClick={() => { setSearchTerm(''); setShowSelectedOnly(false); }}
            className="mt-6 px-6 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black uppercase tracking-widest hover:bg-emerald-500 transition-all"
          >
            Clear all filters
          </button>
        </div>
      )}

      {/* Scroll to Top */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            onClick={scrollToTop}
            className={`fixed bottom-32 right-8 z-50 p-4 rounded-full shadow-2xl border transition-all ${
              isDark ? 'bg-[#1F2937] border-[#2D3748] text-[#F9FAFB] hover:bg-[#2D3748]' : 'bg-white border-slate-200 text-slate-900 hover:bg-slate-50'
            }`}
          >
            <ArrowUpRight className="w-6 h-6 -rotate-45" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Floating Summary Bar */}
      <AnimatePresence>
        {totalItems > 0 && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] w-full max-w-4xl px-4"
          >
            <div className={`flex flex-wrap items-center justify-between gap-6 p-6 rounded-3xl border shadow-2xl backdrop-blur-xl ${
              isDark ? 'bg-[#0F172A]/90 border-[#1F2937]' : 'bg-white/90 border-slate-200'
            }`}>
              <div className="flex items-center gap-8">
                <div className="flex flex-col">
                  <span className={`text-[10px] font-black uppercase tracking-widest mb-1 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Items Selected</span>
                  <span className={`text-2xl font-black tracking-tighter font-syne ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>{totalItems}</span>
                </div>
                <div className={`w-px h-10 ${isDark ? 'bg-[#1F2937]' : 'bg-slate-200'}`} />
                <div className="flex gap-6">
                  <div className="flex flex-col">
                    <span className={`text-[10px] font-black uppercase tracking-widest mb-1 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Cencora</span>
                    <span className={`text-lg font-black font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{cencoraCount}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className={`text-[10px] font-black uppercase tracking-widest mb-1 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Pinnacle</span>
                    <span className={`text-lg font-black font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{pinnacleCount}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className={`text-[10px] font-black uppercase tracking-widest mb-1 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>VaxServe</span>
                    <span className={`text-lg font-black font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{vaxServeCount}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button 
                  onClick={clearAll}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all font-syne ${
                    isDark ? 'bg-[#1F2937] text-[#F9FAFB] hover:bg-[#2D3748]' : 'bg-slate-100 text-slate-900 hover:bg-slate-200'
                  }`}
                >
                  <Trash2 className="w-4 h-4" /> Clear
                </button>
                <button 
                  onClick={handlePrint}
                  className="flex items-center gap-2 px-8 py-3 rounded-2xl bg-emerald-600 text-white text-xs font-black uppercase tracking-widest hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-600/20 font-syne"
                >
                  <Printer className="w-4 h-4" /> Print / Save PDF
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SupplyOrderSheet;
