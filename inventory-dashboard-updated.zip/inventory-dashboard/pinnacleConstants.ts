
import { PinnacleItem } from './types';

export interface ExtendedPinnacleItem extends PinnacleItem {
  category: 'DRUG' | 'SUPPLY';
  vendor?: string;
}

export const PINNACLE_ITEMS: ExtendedPinnacleItem[] = [
  { description: "Water Sterile PF 20mL", price: 49.75, stock: "OUT_OF_STOCK", caseInfo: "25/box", category: "DRUG" },
  { description: "Amikacin 500mg 2mL", price: 80.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Ampicillin 1gm", price: 40.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Cefepime 2gm", price: 54.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Daptomycin 500mg", price: 16.00, stock: "IN_STOCK", caseInfo: "each", category: "DRUG" },
  { description: "Ertapenem 1gm", price: 175.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Meropenem 1gm", price: 48.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Piperacillin Tazobactam 3.375gm", price: 26.00, stock: "IN_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Vancomycin 1gm", price: 24.00, stock: "OUT_OF_STOCK", caseInfo: "10/box", category: "DRUG" },
  { description: "Bandage Cohesive 2\" Multi-Color", price: 41.50, stock: "IN_STOCK", caseInfo: "36/box", category: "SUPPLY" },
  { description: "Spandage Tubular LF Wrap Size 6", price: 12.50, stock: "IN_STOCK", caseInfo: "each", category: "SUPPLY" },
  { description: "Adaptic Dressing 3\" x 3\"", price: 42.00, stock: "IN_STOCK", caseInfo: "50/box", category: "SUPPLY" },
  { description: "Tegaderm Transparent Dressing 2.75\" x 2.375\"", price: 42.00, stock: "IN_STOCK", caseInfo: "100/box", category: "SUPPLY" },
  { description: "Tegaderm Transparent Dressing 4\" x 4.75\"", price: 48.00, stock: "IN_STOCK", caseInfo: "50/box", category: "SUPPLY" },
  { description: "Gauze 2\" x 2\" 8-Ply NS", price: 2.75, stock: "IN_STOCK", caseInfo: "200/bag", category: "SUPPLY" },
  { description: "Alcohol Prep Pads ST Medium", price: 3.75, stock: "IN_STOCK", caseInfo: "200/box", category: "SUPPLY" },
  { description: "Super Sani-Cloth Large Germicidal Wipes", price: 14.00, stock: "IN_STOCK", caseInfo: "160/canister", category: "SUPPLY" },
  { description: "IV Extension Set 7\" Minibore", price: 45.00, stock: "IN_STOCK", caseInfo: "50/box", category: "SUPPLY" },
  { description: "Syringe Cap ST Blue", price: 371.00, stock: "IN_STOCK", caseInfo: "2000/case", category: "SUPPLY" },
  { description: "Ultrasite NF Connector", price: 182.00, stock: "IN_STOCK", caseInfo: "100/box", category: "SUPPLY" },
  { description: "Huber Needle 8\" Set 22g x 3/4\"", price: 260.00, stock: "IN_STOCK", caseInfo: "100/case", category: "SUPPLY" },
  { description: "Huber Needle 8\" Set 22g x 1\"", price: 260.00, stock: "IN_STOCK", caseInfo: "100/case", category: "SUPPLY" }
];
