
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { INFUSION_FAVORITES } from "../constants";

// Corrected initialization to use Named Parameter directly from process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getInventoryInsights = async () => {
  const dataString = JSON.stringify(INFUSION_FAVORITES, null, 2);
  const prompt = `Analyze this pharmaceutical inventory data from Cencora (formerly Besse) and provide high-level insights. 
  Focus on:
  1. Financial impact (list specific unit prices for the top 3 most expensive items).
  2. Stock risks (out of stock items).
  3. Suggested replenishment priorities based on value.
  
  Inventory Data:
  ${dataString}
  
  Format the output as a clean summary with 3-4 bullet points. Use professional medical procurement terminology.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
      }
    });
    // Correctly using the .text property as per guidelines
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Unable to generate insights at this time.";
  }
};

export const chatWithInventory = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  // Correctly passing history to create to maintain conversation state
  const chat = ai.chats.create({
    model: 'gemini-3.1-pro-preview',
    history: history,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
      systemInstruction: `You are an expert pharmaceutical inventory assistant for Cencora. 
      You have access to the "Cencora Infusion Favorites" list. 
      You MUST provide exact "unit_price" values when users ask "where is the price" or "how much does X cost".
      Answer questions concisely based on this inventory data: ${JSON.stringify(INFUSION_FAVORITES)}.
      Note that "BES" numbers are now referred to as ABC# (AmerisourceBergen Corporation number).
      If asked for things not in the data, politely say you don't have that information.`,
    },
  });

  try {
    const response = await chat.sendMessage({ message });
    // Correctly using the .text property as per guidelines
    return response.text;
  } catch (error) {
    console.error("Chat Error:", error);
    return "I'm having trouble processing that request.";
  }
};
