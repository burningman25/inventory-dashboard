
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { OrderUnit } from '../types';

interface OrderItem {
  description: string;
  quantity: number;
  unit: OrderUnit;
  unitPrice: number;
  total: number;
}

export const generateOrderPDF = (vendor: string, items: OrderItem[]) => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const date = new Date().toLocaleDateString();
  const grandTotal = items.reduce((sum, item) => sum + item.total, 0);

  // Header
  doc.setFontSize(22);
  doc.setTextColor(vendor === 'Pinnacle' ? '#0d9488' : '#0891b2'); // Teal for Pinnacle, Cyan for Cencora
  doc.text(`${vendor} Purchase Order`, 14, 22);
  
  doc.setFontSize(10);
  doc.setTextColor('#64748b');
  doc.text(`Generated on: ${date}`, 14, 30);
  
  doc.setDrawColor('#e2e8f0');
  doc.line(14, 35, pageWidth - 14, 35);

  // Table
  const tableRows = items.map(item => [
    item.description,
    item.quantity.toString(),
    item.unit,
    `$${item.unitPrice.toFixed(2)}`,
    `$${item.total.toFixed(2)}`
  ]);

  (doc as any).autoTable({
    startY: 45,
    theme: 'grid', // This enables visible horizontal and vertical borders
    head: [['Description', 'Qty', 'Unit', 'Price/Unit', 'Line Total']],
    body: tableRows,
    styles: {
      fontSize: 9,
      cellPadding: 4,
      lineColor: [226, 232, 240], // Soft gray matching the UI border-slate-200
      lineWidth: 0.1,
      textColor: [30, 41, 59], // Slate-800
    },
    headStyles: { 
      fillColor: vendor === 'Pinnacle' ? [13, 148, 136] : [8, 145, 178], // Teal vs Cyan
      textColor: [255, 255, 255],
      fontSize: 10,
      fontStyle: 'bold',
      halign: 'center'
    },
    columnStyles: {
      0: { cellWidth: 'auto', halign: 'left' },
      1: { halign: 'center', cellWidth: 15 },
      2: { halign: 'center', cellWidth: 20 },
      3: { halign: 'right', cellWidth: 30 },
      4: { halign: 'right', cellWidth: 30 }
    },
    alternateRowStyles: { 
      fillColor: [248, 250, 252] // Very light blue-gray
    },
    margin: { top: 45, left: 14, right: 14 }
  });

  // Footer / Grand Total
  const finalY = (doc as any).lastAutoTable.finalY + 12;
  doc.setFontSize(12);
  doc.setTextColor('#0f172a');
  doc.setFont('helvetica', 'bold');
  doc.text(`Estimated Grand Total: $${grandTotal.toFixed(2)}`, pageWidth - 14, finalY, { align: 'right' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor('#94a3b8');
  doc.text('This is an automatically generated draft order form for internal procurement reference.', 14, finalY + 15);

  // Save the PDF
  doc.save(`${vendor}_Order_${date.replace(/\//g, '-')}.pdf`);
};
