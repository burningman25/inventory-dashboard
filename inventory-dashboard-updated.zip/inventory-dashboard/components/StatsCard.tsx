
import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  color: string;
  highlight?: boolean;
  isDark?: boolean;
}

const StatsCard: React.FC<StatsCardProps> = ({ title, value, icon, trend, color, highlight, isDark }) => {
  if (isDark) {
    return (
      <div className={`bg-[#111827] rounded-xl p-5 border border-[#1F2937] transition-all hover:bg-[#1F2937] group relative overflow-hidden`}>
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          {/* Fix: Check for valid element and cast to React.ReactElement<any> to allow passing className */}
          {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-16 h-16' }) : icon}
        </div>
        <div className="flex items-center gap-3 mb-4">
          <div className={`p-2 rounded-lg ${color} shadow-lg shadow-black/20`}>
            {/* Fix: Check for valid element and cast to React.ReactElement<any> to allow passing className */}
            {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: 'w-5 h-5' }) : icon}
          </div>
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{title}</h3>
        </div>
        <div className="flex items-baseline gap-2">
          <p className="text-3xl font-black text-white tracking-tighter">{value}</p>
          {trend && (
            <span className="text-[10px] font-bold text-emerald-400/80">
              {trend}
            </span>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-xl shadow-sm p-4 sm:p-7 border ${highlight ? 'border-indigo-400 ring-2 ring-indigo-100 ring-opacity-50' : 'border-slate-100'} transition-all hover:shadow-md`}>
      <div className="flex items-center justify-between mb-5 sm:mb-6">
        <div className={`p-2 sm:p-3 rounded-lg ${color}`}>
          {icon}
        </div>
        {trend && (
          <span className="text-[10px] sm:text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
            {trend}
          </span>
        )}
      </div>
      <div>
        <h3 className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-3">{title}</h3>
        <p className="text-2xl sm:text-[28px] font-bold text-slate-900 mt-1 leading-none">{value}</p>
      </div>
    </div>
  );
};

export default StatsCard;
