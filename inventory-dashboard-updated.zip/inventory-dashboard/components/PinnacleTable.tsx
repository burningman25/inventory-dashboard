
import React from 'react';
import { PinnacleItem, OrderUnit, OrderSelection } from '../types';

interface PinnacleTableProps {
  items: PinnacleItem[];
  selectedItems: Record<string, OrderSelection>;
  onSelectionChange: (description: string, isSelected: boolean, quantity?: number, unit?: OrderUnit) => void;
  onSelectAll: (isSelected: boolean) => void;
  onSort?: (key: keyof PinnacleItem) => void;
  currentSort?: { key: keyof PinnacleItem; direction: 'asc' | 'desc' } | null;
  isDark?: boolean;
}

const PinnacleTable: React.FC<PinnacleTableProps> = ({ 
  items, 
  selectedItems, 
  onSelectionChange, 
  onSelectAll,
  onSort, 
  currentSort,
  isDark = false
}) => {
  const isAllSelected = items.length > 0 && items.every(item => !!selectedItems[item.description]);

  const renderSortIcon = (key: keyof PinnacleItem) => {
    if (currentSort?.key !== key) return null;
    return <span className="ml-1">{currentSort.direction === 'asc' ? '↑' : '↓'}</span>;
  };

  const colors = {
    th: isDark ? 'bg-[#111827] text-slate-400 border-[#1F2937]' : 'bg-slate-50 text-slate-500 border-slate-200',
    td: isDark ? 'bg-[#0F172A] text-slate-300 border-[#1F2937]' : 'bg-white text-slate-900 border-slate-200',
    input: isDark ? 'bg-[#111827] border-[#1F2937] text-white focus:ring-emerald-500' : 'bg-white border-slate-200 text-slate-900 focus:ring-emerald-600',
    rowHover: isDark ? 'hover:bg-[#1F2937]/50' : 'hover:bg-slate-50/50',
    selectedRow: isDark ? 'bg-emerald-500/5' : 'bg-emerald-50/30'
  };

  return (
    <div className="w-full overflow-visible transition-colors duration-500">
      <table className={`min-w-full border-collapse border ${isDark ? 'border-[#1F2937]' : 'border-slate-200'}`}>
        <thead>
          <tr className="z-20">
            <th className={`sticky top-16 px-4 py-4 text-center border w-12 z-20 transition-colors duration-500 ${colors.th}`}>
              <input 
                type="checkbox" 
                checked={isAllSelected}
                onChange={(e) => onSelectAll(e.target.checked)}
                className={`w-4 h-4 rounded border-slate-300 transition-colors ${isDark ? 'bg-[#111827] border-[#1F2937] text-emerald-500' : 'text-emerald-600 focus:ring-emerald-500'} cursor-pointer`}
              />
            </th>
            <th className={`sticky top-16 px-4 py-4 text-center text-[11px] font-bold uppercase tracking-wider w-12 border z-20 transition-colors duration-500 ${colors.th}`}>#</th>
            <th className={`sticky top-16 px-4 py-4 text-center text-[11px] font-bold uppercase tracking-wider border w-44 z-20 transition-colors duration-500 ${colors.th}`}>ORDER QTY / UNIT</th>
            <th 
              className={`sticky top-16 px-6 py-4 text-left text-[11px] font-bold uppercase tracking-wider cursor-pointer border z-20 transition-all duration-500 ${colors.th} ${isDark ? 'hover:bg-[#1F2937]' : 'hover:bg-slate-100'}`}
              onClick={() => onSort?.('description')}
            >
              DESCRIPTION {renderSortIcon('description')}
            </th>
            <th 
              className={`sticky top-16 px-6 py-4 text-left text-[11px] font-bold uppercase tracking-wider cursor-pointer border z-20 transition-all duration-500 ${isDark ? 'bg-[#111827] border-[#1F2937] text-emerald-400 hover:bg-[#1F2937]' : 'bg-slate-50 border-slate-200 text-emerald-600 hover:bg-emerald-50'}`}
              onClick={() => onSort?.('price')}
            >
              PRICE/UNIT {renderSortIcon('price')}
            </th>
            <th className={`sticky top-16 px-6 py-4 text-left text-[11px] font-bold uppercase tracking-wider border z-20 transition-colors duration-500 ${colors.th}`}>STOCK</th>
            <th className={`sticky top-16 px-6 py-4 text-left text-[11px] font-bold uppercase tracking-wider border z-20 transition-colors duration-500 ${colors.th}`}>CASE INFO</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, idx) => (
            <tr key={`pinnacle-${idx}`} className={`transition-colors duration-300 ${colors.rowHover} ${selectedItems[item.description] !== undefined ? colors.selectedRow : ''}`}>
              <td className={`px-4 py-4 text-center border transition-colors duration-500 ${colors.td}`}>
                 <input 
                  type="checkbox" 
                  checked={!!selectedItems[item.description]}
                  onChange={(e) => onSelectionChange(item.description, e.target.checked)}
                  className={`w-4 h-4 rounded border-slate-300 transition-colors ${isDark ? 'bg-[#111827] border-[#1F2937] text-emerald-500' : 'text-emerald-600 focus:ring-emerald-500'} cursor-pointer`}
                />
              </td>
              <td className={`px-4 py-4 whitespace-nowrap text-center text-[12px] font-bold border transition-colors duration-500 ${colors.td} opacity-50`}>
                {idx + 1}
              </td>
              <td className={`px-4 py-4 border text-center transition-colors duration-500 ${colors.td}`}>
                <div className="flex items-center gap-2 justify-center">
                  <input 
                    type="number" 
                    min="1"
                    disabled={selectedItems[item.description] === undefined}
                    value={selectedItems[item.description]?.quantity || 1}
                    onChange={(e) => onSelectionChange(item.description, true, parseInt(e.target.value) || 1)}
                    className={`w-16 px-2 py-1.5 border rounded text-sm text-center outline-none transition-all duration-500 ${colors.input} ${selectedItems[item.description] === undefined ? 'opacity-20 cursor-not-allowed' : 'opacity-100'}`}
                  />
                  <select
                    disabled={selectedItems[item.description] === undefined}
                    value={selectedItems[item.description]?.unit || 'Boxes'}
                    onChange={(e) => onSelectionChange(item.description, true, selectedItems[item.description].quantity, e.target.value as OrderUnit)}
                    className={`px-2 py-1.5 border rounded text-sm outline-none transition-all duration-500 ${colors.input} ${selectedItems[item.description] === undefined ? 'opacity-20 cursor-not-allowed' : 'opacity-100'}`}
                  >
                    <option value="Boxes">Boxes</option>
                    <option value="Cases">Cases</option>
                  </select>
                </div>
              </td>
              <td className={`px-6 py-4 border transition-colors duration-500 ${colors.td}`}>
                <div className="text-sm font-semibold leading-tight">{item.description}</div>
              </td>
              <td className={`px-6 py-4 whitespace-nowrap border transition-colors duration-500 ${colors.td}`}>
                <div className={`text-sm font-black ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>${item.price.toFixed(2)}</div>
              </td>
              <td className={`px-6 py-4 whitespace-nowrap border transition-colors duration-500 ${colors.td}`}>
                <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-tighter transition-all ${
                  item.stock === 'IN_STOCK' 
                    ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-emerald-100 text-emerald-600 border border-emerald-200')
                    : (isDark ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-rose-100 text-rose-600 border border-rose-200')
                }`}>
                  {item.stock === 'IN_STOCK' ? 'IN STOCK' : 'OUT'}
                </span>
              </td>
              <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium border transition-colors duration-500 ${colors.td} opacity-70`}>
                {item.caseInfo}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PinnacleTable;
