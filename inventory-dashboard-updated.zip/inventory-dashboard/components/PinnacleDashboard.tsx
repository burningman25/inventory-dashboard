
import React, { useState, useMemo, useEffect } from 'react';
import { PINNACLE_ITEMS, ExtendedPinnacleItem } from '../pinnacleConstants';
import { PinnacleItem, OrderUnit, OrderSelection } from '../types';
import StatsCard from './StatsCard';
import { generateOrderPDF } from '../services/pdfService';
import { supabase } from '../supabaseClient';

type PinnacleCategory = 'ALL' | 'DRUGS' | 'SUPPLIES' | 'DRESSINGS' | 'IV SETS' | 'SYRINGES';

interface PinnacleDashboardProps {
  isDark?: boolean;
}

const PinnacleDashboard: React.FC<PinnacleDashboardProps> = ({ isDark = true }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'IN_STOCK' | 'OUT_OF_STOCK'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<PinnacleCategory>('ALL');
  const [selectedItems, setSelectedItems] = useState<Record<string, OrderSelection>>({});
  const [dbItems, setDbItems] = useState<ExtendedPinnacleItem[]>([]);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const { data, error } = await supabase.from('inventory_items').select('*');
        if (error) {
          console.error('Error fetching from Supabase:', error);
          return;
        }
        if (data) {
          const mappedItems: ExtendedPinnacleItem[] = data.map(item => ({
            description: item.description,
            price: item.unit_price,
            stock: 'IN_STOCK', // Defaulting to IN_STOCK for parsed items
            caseInfo: `${item.quantity}/box`, // Assuming quantity is per box based on invoice
            category: 'SUPPLY', // Defaulting to SUPPLY, could be enhanced
            vendor: item.vendor || 'PINNACLE'
          }));
          setDbItems(mappedItems);
        }
      } catch (err) {
        console.error('Failed to fetch from Supabase:', err);
      }
    };

    fetchItems();

    const channel = supabase
      .channel('inventory_items_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'inventory_items' },
        () => {
          fetchItems();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const allItems = useMemo(() => {
    // Merge static items with DB items, preferring DB items if descriptions match
    const merged = [...PINNACLE_ITEMS];
    dbItems.forEach(dbItem => {
      const existingIndex = merged.findIndex(i => i.description.toLowerCase() === dbItem.description.toLowerCase());
      if (existingIndex >= 0) {
        merged[existingIndex] = { ...merged[existingIndex], ...dbItem };
      } else {
        merged.push(dbItem);
      }
    });
    return merged;
  }, [dbItems]);

  const categorizeItem = (item: ExtendedPinnacleItem): PinnacleCategory => {
    const desc = item.description.toLowerCase();
    if (desc.includes('dressing') || desc.includes('gauze') || desc.includes('bandage') || 
        desc.includes('spandage') || desc.includes('tegaderm') || desc.includes('adaptic')) {
      return 'DRESSINGS';
    }
    if (desc.includes('extension set')) return 'IV SETS';
    if (desc.includes('syringe') || desc.includes('huberr needle')) return 'SYRINGES';
    if (item.category === 'DRUG') return 'DRUGS';
    return 'SUPPLIES';
  };

  const filteredItems = useMemo(() => {
    return allItems.filter(item => {
      const matchesSearch = item.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'ALL' || item.stock === statusFilter;
      const matchesCategory = categoryFilter === 'ALL' || categorizeItem(item) === categoryFilter;
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [allItems, searchTerm, statusFilter, categoryFilter]);

  const categoryCounts = useMemo(() => {
    const counts: Record<PinnacleCategory, number> = {
      ALL: allItems.length,
      DRUGS: 0,
      SUPPLIES: 0,
      DRESSINGS: 0,
      'IV SETS': 0,
      SYRINGES: 0
    };
    allItems.forEach(item => {
      counts[categorizeItem(item)]++;
    });
    return counts;
  }, [allItems]);

  const stats = useMemo(() => {
    const total = allItems.length;
    const stocked = allItems.filter(i => i.stock === 'IN_STOCK').length;
    const oos = allItems.filter(i => i.stock === 'OUT_OF_STOCK').length;
    const atRisk = allItems
      .filter(i => i.stock === 'OUT_OF_STOCK')
      .reduce((acc, curr) => acc + curr.price, 0);
    
    return { total, stocked, oos, atRisk };
  }, [allItems]);

  const handleSelectionChange = (description: string, isSelected: boolean, quantity?: number, unit?: OrderUnit) => {
    setSelectedItems(prev => {
      const next = { ...prev };
      if (isSelected) {
        next[description] = {
          quantity: quantity ?? next[description]?.quantity ?? 1,
          unit: unit ?? next[description]?.unit ?? 'Boxes'
        };
      } else {
        delete next[description];
      }
      return next;
    });
  };

  const handleClearSelection = () => setSelectedItems({});

  const getMultiplier = (item: PinnacleItem) => {
    const match = item.caseInfo.match(/(\d+)\s+boxes|(\d+)\/box|(\d+)\/case/i);
    return match ? (parseInt(match[1] || match[2] || match[3]) || 1) : 1;
  };

  const handleGeneratePDF = () => {
    const orderItems = (Object.entries(selectedItems) as [string, OrderSelection][]).map(([desc, selection]) => {
      const item = allItems.find(i => i.description === desc)!;
      const multiplier = selection.unit === 'Cases' ? getMultiplier(item) : 1;
      return {
        description: item.description,
        quantity: selection.quantity,
        unit: selection.unit,
        unitPrice: item.price * multiplier,
        total: selection.quantity * item.price * multiplier
      };
    });
    generateOrderPDF('Pinnacle', orderItems);
  };

  const selectedCount = Object.keys(selectedItems).length;
  const estimatedTotal = (Object.entries(selectedItems) as [string, OrderSelection][]).reduce((sum, [desc, selection]) => {
    const item = allItems.find(i => i.description === desc);
    if (!item) return sum;
    const multiplier = selection.unit === 'Cases' ? getMultiplier(item) : 1;
    return sum + (item.price * multiplier * selection.quantity);
  }, 0);

  const getPriceColor = (price: number) => {
    if (price < 100) return isDark ? 'text-[#22C55E]' : 'text-emerald-600';
    if (price < 1000) return isDark ? 'text-[#F59E0B]' : 'text-amber-600';
    return isDark ? 'text-[#EF4444]' : 'text-rose-600';
  };

  const colors = {
    bg: isDark ? 'bg-[#0B1220]' : 'bg-[#F8FAFC]',
    panel: isDark ? 'bg-[#0F172A]' : 'bg-[#FFFFFF]',
    card: isDark ? 'bg-[#1E293B]' : 'bg-[#FFFFFF]',
    textPrimary: isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]',
    textSecondary: isDark ? 'text-[#CBD5E1]' : 'text-[#64748B]',
    border: isDark ? 'border-[#334155]' : 'border-slate-200'
  };

  return (
    <div className={`space-y-8 pb-32 transition-colors duration-500 ${colors.bg} min-h-full`}>
      <div className="flex flex-col gap-1 mb-8">
        <h2 className={`text-3xl font-black transition-colors duration-500 ${colors.textPrimary} tracking-tighter uppercase`}>Revenue Inventory Dashboard</h2>
        <p className={`transition-colors duration-500 ${colors.textSecondary} text-sm font-medium tracking-wide uppercase`}>Real-time procurement & risk assessment</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Items" 
          value={stats.total} 
          isDark={isDark} color={isDark ? "bg-[#1F2937] text-[#CBD5E1]" : "bg-slate-100 text-slate-600"}
          icon={<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>}
        />
        <StatsCard 
          title="Ready (Stocked)" 
          value={stats.stocked} 
          isDark={isDark} color="bg-[#22C55E]/10 text-[#22C55E]"
          icon={<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>}
        />
        <StatsCard 
          title="Blocked (OOS)" 
          value={stats.oos} 
          isDark={isDark} color="bg-[#EF4444]/10 text-[#EF4444]"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>}
        />
        <StatsCard 
          title="$ At Risk" 
          value={`$${stats.atRisk.toLocaleString()}`} 
          isDark={isDark} color="bg-[#F59E0B]/10 text-[#F59E0B]"
          icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" strokeWidth="2"/><circle cx="12" cy="12" r="4" strokeWidth="2"/></svg>}
        />
      </div>

      <div className="space-y-4">
        <div className={`flex flex-col md:flex-row gap-4 items-center justify-between p-4 rounded-xl border transition-all duration-500 ${colors.panel} ${isDark ? 'border-[#334155]' : 'border-slate-200'}`}>
          <div className="relative w-full md:w-80">
            <input 
              type="text" 
              placeholder="Search Pinnacle Inventory..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full border ${isDark ? 'bg-[#111827] border-[#334155] text-[#F9FAFB] placeholder-[#6B7280]' : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'} pl-10 pr-4 py-2.5 rounded-lg text-sm focus:ring-2 focus:ring-[#3b82f6] outline-none transition-all`}
            />
            <svg className={`w-5 h-5 absolute left-3 top-2.5 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
          
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            <div className={`flex h-10 items-center gap-1 p-1 rounded-lg border ${isDark ? 'bg-[#111827] border-[#334155]' : 'bg-slate-100 border-slate-200'}`}>
              {[
                { label: 'ALL', value: 'ALL' },
                { label: 'IN STOCK', value: 'IN_STOCK' },
                { label: 'OUT', value: 'OUT_OF_STOCK' }
              ].map((f) => (
                <button
                  key={f.value}
                  onClick={() => setStatusFilter(f.value as any)}
                  className={`px-3 py-1.5 text-[10px] font-black rounded transition-all uppercase tracking-wider ${
                    statusFilter === f.value 
                      ? (isDark ? 'bg-[#3b82f6] text-[#0B1220]' : 'bg-blue-600 text-white shadow-md')
                      : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Categories Section */}
        <div className="flex flex-wrap items-center gap-2 px-1">
          {(['ALL', 'DRUGS', 'SUPPLIES', 'DRESSINGS', 'IV SETS', 'SYRINGES'] as PinnacleCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider transition-all border ${
                categoryFilter === cat
                  ? (isDark ? 'bg-blue-500/10 text-blue-400 border-blue-500/40 shadow-[0_0_15px_rgba(59,130,246,0.1)]' : 'bg-blue-600 text-white border-blue-600 shadow-md')
                  : (isDark ? 'bg-[#111827] border-[#334155] text-slate-400 hover:border-slate-500 hover:text-slate-300' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50')
              }`}
            >
              {cat} <span className={`ml-1 opacity-50 font-mono`}>({categoryCounts[cat]})</span>
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-6 px-4 pt-2">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isDark ? 'bg-[#22C55E]' : 'bg-emerald-600'}`}></div>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${colors.textSecondary}`}>Under $100: Low Cost</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isDark ? 'bg-[#F59E0B]' : 'bg-amber-600'}`}></div>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${colors.textSecondary}`}>$100 - $999: Med Cost</span>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${isDark ? 'bg-[#EF4444]' : 'bg-rose-600'}`}></div>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${colors.textSecondary}`}>$1,000+: High Cost / Risk</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <div 
            key={item.description} 
            className={`group relative rounded-xl border-2 transition-all duration-300 hover:-translate-y-1 ${
              isDark 
                ? `bg-[#1E293B] shadow-xl shadow-black/40 ${selectedItems[item.description] ? 'border-[#3b82f6]' : 'border-[#334155] hover:border-[#3b82f6]/50'}`
                : `bg-white border-slate-200 shadow-sm hover:shadow-md ${selectedItems[item.description] ? 'border-blue-500 shadow-blue-100' : 'border-slate-100'}`
            }`}
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4 gap-4">
                <div className="flex-1">
                   <h3 className={`text-lg font-black leading-tight uppercase group-hover:text-[#3b82f6] transition-colors ${colors.textPrimary}`}>
                    {item.description}
                  </h3>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${isDark ? 'bg-black/20 text-slate-400 border border-[#334155]' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
                      {item.caseInfo || '—'}
                    </span>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${item.category === 'DRUG' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'}`}>
                      {categorizeItem(item)}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <input 
                    type="checkbox" 
                    checked={!!selectedItems[item.description]}
                    onChange={(e) => handleSelectionChange(item.description, e.target.checked)}
                    className={`w-5 h-5 rounded cursor-pointer ${isDark ? 'border-[#334155] bg-[#0F172A] text-[#3b82f6] focus:ring-[#3b82f6]' : 'border-slate-300 text-blue-600 focus:ring-blue-500'}`}
                  />
                  <span className={`px-2.5 py-0.5 text-[9px] font-black rounded border tracking-widest transition-all ${
                    item.stock === 'IN_STOCK' 
                      ? (isDark ? 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/30 glow-pill' : 'bg-emerald-100 text-emerald-700 border-emerald-200')
                      : (isDark ? 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/30' : 'bg-rose-100 text-rose-700 border-rose-200')
                  }`}>
                    {item.stock === 'IN_STOCK' ? 'IN STOCK' : 'OUT'}
                  </span>
                </div>
              </div>

              <div className={`flex items-center justify-between py-4 border-y my-4 transition-colors duration-500 ${isDark ? 'border-[#334155]' : 'border-slate-100'}`}>
                <div className="flex flex-col">
                  <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#94A3B8]' : 'text-slate-400'}`}>Vendor</span>
                  <span className={`text-xs font-bold font-mono ${isDark ? 'text-[#CBD5E1]' : 'text-slate-600'}`}>{item.vendor || 'PINNACLE'}</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-[#94A3B8]' : 'text-slate-400'}`}>Unit Price</span>
                  <span className={`text-2xl font-black tracking-tighter ${getPriceColor(item.price)}`}>
                    ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className={`transition-all duration-300 ${selectedItems[item.description] ? 'opacity-100' : 'opacity-30 grayscale pointer-events-none'}`}>
                <div className="flex items-center gap-3">
                  <div className={`flex-1 flex items-center rounded-lg p-1 border transition-colors duration-500 ${isDark ? 'bg-[#0F172A] border-[#334155]' : 'bg-white border-slate-200'}`}>
                    <input 
                      type="number" 
                      min="1"
                      value={selectedItems[item.description]?.quantity || 1}
                      onChange={(e) => handleSelectionChange(item.description, true, parseInt(e.target.value) || 1)}
                      className={`w-full bg-transparent text-center font-black text-sm outline-none px-2 ${isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]'}`}
                    />
                  </div>
                  <div className="flex-1">
                    <select
                      value={selectedItems[item.description]?.unit || 'Boxes'}
                      onChange={(e) => handleSelectionChange(item.description, true, selectedItems[item.description]?.quantity, e.target.value as OrderUnit)}
                      className={`w-full border text-xs font-black p-2 rounded-lg outline-none cursor-pointer uppercase tracking-widest transition-colors duration-500 ${isDark ? 'bg-[#0F172A] border-[#334155] text-[#F9FAFB]' : 'bg-white border-slate-200 text-slate-700'}`}
                    >
                      <option value="Boxes">Boxes</option>
                      <option value="Cases">Cases</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedCount > 0 && (
        <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 w-[95%] max-w-5xl backdrop-blur-md shadow-2xl rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-6 z-[100] border-2 transition-all duration-500 ${isDark ? 'bg-[#0F172A]/98 border-[#F97316]/30 shadow-black' : 'bg-white border-orange-100'}`}>
          <div className="flex items-center gap-10">
             <div className="flex flex-col">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Batch Size</span>
              <div className="flex items-center gap-3">
                <span className={`text-xl font-black leading-none ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>{selectedCount} <span className="text-[#F97316] text-sm uppercase font-black">items selected</span></span>
                <button 
                  onClick={handleClearSelection}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${isDark ? 'text-slate-400 hover:text-white hover:bg-white/5' : 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'}`}
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  Clear
                </button>
              </div>
            </div>
            <div className={`w-px h-12 ${isDark ? 'bg-[#1F2937]' : 'bg-slate-100'}`}></div>
            <div className="flex flex-col">
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Capital Expenditure</span>
              <span className={`text-3xl font-black leading-none ${isDark ? 'text-[#F97316]' : 'text-orange-600'}`}>
                <span className="text-xl mr-1 opacity-50">$</span>
                {estimatedTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
          <button 
            onClick={handleGeneratePDF}
            className={`w-full md:w-auto px-10 py-4 font-black rounded-xl transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-sm bg-[#F97316] text-[#0B1220] hover:bg-orange-400 shadow-orange-500/40`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            Finalize Procurement
          </button>
        </div>
      )}

      <style>{`
        .glow-pill {
          box-shadow: 0 0 10px rgba(34,197,94,0.15);
          animation: pulse-glow 3s infinite ease-in-out;
        }
        @keyframes pulse-glow {
          0% { box-shadow: 0 0 8px rgba(34,197,94,0.1); }
          50% { box-shadow: 0 0 18px rgba(34,197,94,0.4); border-color: rgba(34,197,94,0.5); }
          100% { box-shadow: 0 0 8px rgba(34,197,94,0.1); }
        }
      `}</style>
    </div>
  );
};

export default PinnacleDashboard;
