import React, { useState } from 'react';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { Upload, FileText, Loader2, CheckCircle2, AlertCircle, Database, RefreshCw } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { INFUSION_FAVORITES } from '../constants';
import { PINNACLE_ITEMS } from '../pinnacleConstants';
import { VAXSERVE_ITEMS } from '../vaxserveConstants';
import { formatNDC } from '../utils';

interface InvoiceParserProps {
  isDark: boolean;
}

interface ExtractedItem {
  invoice_number: string;
  invoice_date: string;
  order_date?: string;
  vendor: string;
  item_code: string;
  ndc?: string;
  description: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  pack_size?: string;
  items_per_box?: number;
}

const InvoiceParser: React.FC<InvoiceParserProps> = ({ isDark }) => {
  const [file, setFile] = useState<File | null>(null);
  const [userPrompt, setUserPrompt] = useState('Extract items from Pinnacle Invoice.');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [extractedData, setExtractedData] = useState<ExtractedItem[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setExtractedData(null);
      setError(null);
      setSaveSuccess(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const base64 = reader.result.split(',')[1];
          resolve(base64);
        } else {
          reject(new Error('Failed to convert file to base64'));
        }
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleExtract = async () => {
    if (!file) {
      setError('Please select a file first.');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setExtractedData(null);
    setSaveSuccess(false);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('Gemini API Key is missing. Please set it in your environment variables.');
      }

      const ai = new GoogleGenAI({ apiKey });
      const base64Data = await fileToBase64(file);

      const allExistingItems = [
        ...INFUSION_FAVORITES.map(i => ({ description: i.description, bes_number: i.bes_number, item_number: i.item_number, ndc: i.ndc })),
        ...PINNACLE_ITEMS.map(i => ({ description: i.description, bes_number: null, item_number: null, ndc: null })),
        ...VAXSERVE_ITEMS.map(i => ({ description: i.description, bes_number: null, item_number: i.itemNumber, ndc: i.ndc }))
      ];

      const systemInstruction = `Role: You are a specialized medical supply data extractor. Your goal is to convert PDF invoice text into a structured JSON format compatible with an inventory database.
Task: Extract all line items from the provided invoice (handles both Pinnacle and Cencora/AmerisourceBergen invoices).
Output Format: Return ONLY a valid JSON array of objects. Do not include conversational text or markdown code blocks outside of the JSON.

CRITICAL FIELD DEFINITIONS — do NOT mix these up:
- ndc: The National Drug Code (NDC#). Standard format is 5-4-2 with hyphens (e.g., "60793-0701-10"). This is a drug identifier, NEVER the same as ABC# or item_code. If the "Item" column contains 11 digits that look like an NDC, assign to 'ndc', NOT 'item_code'.
- bes_number: The ABC/BES internal warehouse number (ABC#). This is a long numeric ID (e.g., "10243654"). Found labeled "ABC#" or "BES#" on invoices.
- item_code: The shorter vendor item/order number (e.g., "708664"). Found labeled "Item Number", "ABC 6#", or "Item" on invoices. NOT the NDC.

Extraction Rules:
vendor: Extract the vendor name (e.g., "PINNACLE", "CENCORA", "BESSE", "ASD SPECIALTY").
bes_number: Extract the ABC/BES warehouse number (ABC#) — the longer numeric ID.
item_code: Extract the shorter item/order number. If the value looks like an NDC, assign it to 'ndc' instead.
ndc: Extract the NDC# if available. Format as 5-4-2 (e.g., "60793-0701-10").
description: Extract the full text from the "Description" column, including any notes.
quantity: Extract as an integer from "Qty" or "Quantity". If not found, default to 1.
unit_price: Extract the value from the "Rate" or "Unit Price" column as a float (no "$" signs).
total_amount: Extract the value from the "Amount" or "Extended Amount" column.
pack_size: Extract the packaging size or UOM. If not found, set to null.
items_per_box: Number of individual items per box (e.g., "10X2 ML" → 10). Single item = 1.
metadata: Include invoice_number, invoice_date (Date Stamp), and order_date per line item.

CRITICAL: You MUST map the extracted item to one of the existing products if it is a match (even if slightly abbreviated or misspelled).
Here is the list of existing products:
${JSON.stringify(allExistingItems)}

If the item matches, use the EXACT "description", "bes_number", and "item_code" from the list above.

Schema:
[
  {
    "invoice_number": "string",
    "invoice_date": "string",
    "order_date": "string | null",
    "vendor": "string",
    "bes_number": "string | null — ABC/BES warehouse number (ABC#)",
    "item_code": "string — shorter item/order number, NOT the NDC",
    "ndc": "string | null — NDC# only, formatted as 5-4-2 (e.g. 60793-0701-10)",
    "description": "string",
    "quantity": "number",
    "unit_price": "number",
    "total_amount": "number",
    "pack_size": "string | null",
    "items_per_box": "number"
  }
]`;

      const mimeType = file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');

      const fetchPromise = ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType,
              },
            },
            { text: userPrompt }
          ]
        },
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
        }
      });

      // Add a 60-second timeout to prevent infinite spinning
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('Request timed out after 60 seconds. The file might be too large or the API is busy.')), 60000);
      });

      const response = await Promise.race([fetchPromise, timeoutPromise]);

      const text = response.text;
      if (!text) {
        throw new Error('Received empty response from the model.');
      }

      let parsedData: ExtractedItem[];
      try {
        parsedData = JSON.parse(text);
      } catch (e) {
        const match = text.match(/\[[\s\S]*\]/);
        if (match) {
          parsedData = JSON.parse(match[0]);
        } else {
          throw new Error('Failed to parse the response as JSON.');
        }
      }

      // Match item codes before setting result
      const enrichedData = parsedData.map((item: any, idx: number) => {
        let matchedBesNumber = item.bes_number || null;
        let matchedItemCode = item.item_code || null;

        if (item.ndc) {
          const cencoraMatch = INFUSION_FAVORITES.find(i => i.ndc === item.ndc);
          if (cencoraMatch) {
            matchedBesNumber = cencoraMatch.bes_number;
            matchedItemCode = cencoraMatch.item_number;
          }
        }

        if (!matchedBesNumber && item.description) {
          const cencoraMatch = INFUSION_FAVORITES.find(i => i.description.toLowerCase() === item.description?.toLowerCase());
          if (cencoraMatch) {
            matchedBesNumber = cencoraMatch.bes_number;
            matchedItemCode = cencoraMatch.item_number;
          }

          if (!matchedItemCode) {
            const pinnacleMatch = PINNACLE_ITEMS.find(i => i.description.toLowerCase() === item.description?.toLowerCase());
            if (pinnacleMatch) matchedItemCode = `PINN-${pinnacleMatch.description.replace(/[^a-zA-Z0-9]/g, '').substring(0, 15).toUpperCase()}-${idx}`;
          }

          if (!matchedItemCode) {
            const vaxserveMatch = VAXSERVE_ITEMS.find(i => i.description.toLowerCase() === item.description?.toLowerCase());
            if (vaxserveMatch) matchedItemCode = vaxserveMatch.itemNumber;
          }
        }

        return {
          ...item,
          bes_number: matchedBesNumber,
          item_code: matchedItemCode || `INV-${Date.now()}-${idx}`
        };
      });

      setExtractedData(enrichedData);
      // Automatically save to Supabase
      await handleSaveToSupabase(enrichedData);
    } catch (err: any) {
      console.error('Extraction error:', err);
      setError(err.message || 'An error occurred during extraction.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveToSupabase = async (dataToSave = extractedData) => {
    if (!dataToSave || dataToSave.length === 0) return;

    setIsSaving(true);
    setError(null);
    setSaveSuccess(false);

    try {
      // Upsert data into 'inventory_items' table
      let payload = dataToSave.map((item, idx) => {
        return {
          item_code: item.item_code || `INV-${Date.now()}-${idx}`,
          bes_number: (item as any).bes_number || null,
          description: item.description,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total_amount: item.total_amount,
          invoice_number: item.invoice_number,
          invoice_date: item.invoice_date,
          updated_at: new Date().toISOString(),
          ndc: item.ndc ? item.ndc.replace(/-/g, '').replace(/(\d{5})(\d{4})(\d{2})/, '$1-$2-$3') : null,
          vendor: item.vendor
        };
      });

      let { error: dbError } = await supabase
        .from('inventory_items')
        .upsert(payload, { onConflict: 'item_code' });

      if (dbError && (dbError.message.includes('schema cache') || dbError.message.includes('ndc') || dbError.message.includes('bes_number'))) {
        const payloadStripped = payload.map(p => {
          const { ndc, bes_number, ...rest } = p;
          return rest;
        });
        const retry = await supabase
          .from('inventory_items')
          .upsert(payloadStripped, { onConflict: 'item_code' });
        dbError = retry.error;
      }

      if (dbError) {
        throw new Error(dbError.message);
      }

      setSaveSuccess(true);
    } catch (err: any) {
      console.error('Supabase save error:', err);
      if (err.message?.includes('schema cache') || err.message?.includes('ndc') || err.message?.includes('vendor')) {
        setError('Missing columns in Supabase. Please run this SQL in your Supabase SQL Editor: ALTER TABLE inventory_items ADD COLUMN IF NOT EXISTS vendor TEXT, ADD COLUMN IF NOT EXISTS ndc TEXT;');
      } else {
        setError(err.message || 'Failed to save data to Supabase.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleSyncCatalog = async () => {
    setIsSaving(true);
    setError(null);
    setSaveSuccess(false);

    try {
      const cencoraItems = INFUSION_FAVORITES.map((item, index) => ({
        item_code: item.item_number || `CENCORA-${index}`,
        bes_number: item.bes_number,
        description: item.description,
        quantity: 1,
        unit_price: item.unit_price,
        total_amount: item.unit_price,
        invoice_number: 'CATALOG_SYNC',
        invoice_date: new Date().toISOString().split('T')[0],
        updated_at: new Date().toISOString(),
        ndc: item.ndc
      }));

      const pinnacleItems = PINNACLE_ITEMS.map((item, index) => ({
        item_code: `PINN-${item.description.replace(/[^a-zA-Z0-9]/g, '').substring(0, 15).toUpperCase()}-${index}`,
        bes_number: null,
        description: item.description,
        quantity: 1,
        unit_price: item.price,
        total_amount: item.price,
        invoice_number: 'CATALOG_SYNC',
        invoice_date: new Date().toISOString().split('T')[0],
        updated_at: new Date().toISOString()
      }));

      const vaxserveItems = VAXSERVE_ITEMS.map((item, index) => ({
        item_code: item.itemNumber || `VAX-${index}`,
        bes_number: null,
        description: item.description,
        quantity: 1,
        unit_price: item.price,
        total_amount: item.price,
        invoice_number: 'CATALOG_SYNC',
        invoice_date: new Date().toISOString().split('T')[0],
        updated_at: new Date().toISOString(),
        ndc: item.ndc
      }));

      const allCatalogItems = [...cencoraItems, ...pinnacleItems, ...vaxserveItems];

      // Upsert in batches to avoid payload limits
      const batchSize = 50;
      for (let i = 0; i < allCatalogItems.length; i += batchSize) {
        const batch = allCatalogItems.slice(i, i + batchSize);
        let { error: dbError } = await supabase
          .from('inventory_items')
          .upsert(batch, { onConflict: 'item_code' });

        if (dbError && (dbError.message.includes('schema cache') || dbError.message.includes('ndc'))) {
          const batchWithoutNdc = batch.map(p => {
            const { ndc, ...rest } = p as any;
            return rest;
          });
          const retry = await supabase
            .from('inventory_items')
            .upsert(batchWithoutNdc, { onConflict: 'item_code' });
          dbError = retry.error;
        }

        if (dbError) throw new Error(dbError.message);
      }

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      console.error('Catalog sync error:', err);
      if (err.message?.includes('schema cache') || err.message?.includes('inventory_items')) {
        setError('Table "inventory_items" does not exist in Supabase. Please run the SQL script in your Supabase SQL Editor to create it.');
      } else {
        setError(err.message || 'Failed to sync catalog to Supabase.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className={`mb-8 p-8 rounded-3xl border ${isDark ? 'bg-[#0F172A] border-[#1F2937]' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-2xl ${isDark ? 'bg-blue-500/10 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
              <FileText className="w-8 h-8" />
            </div>
            <div>
              <h1 className={`text-3xl font-black tracking-tighter font-syne ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>Invoice Parser</h1>
              <p className={`text-sm font-medium ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                Extract structured data from medical supply invoices using AI.
              </p>
            </div>
          </div>
          <button
            onClick={handleSyncCatalog}
            disabled={isSaving || saveSuccess}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
              isSaving
                ? (isDark ? 'bg-[#1F2937] text-[#6B7280] cursor-not-allowed' : 'bg-slate-100 text-slate-400 cursor-not-allowed')
                : saveSuccess
                ? 'bg-green-500 text-white border border-green-600'
                : (isDark ? 'bg-[#1E293B] text-[#CBD5E1] hover:bg-[#334155] border border-[#334155]' : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200 shadow-sm')
            }`}
          >
            {saveSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Synced!
              </>
            ) : (
              <>
                <RefreshCw className={`w-4 h-4 ${isSaving ? 'animate-spin' : ''}`} />
                {isSaving ? 'Syncing...' : 'Sync Catalog to DB'}
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="space-y-6">
            <div>
              <label className={`block text-xs font-black uppercase tracking-widest mb-2 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                1. Upload Invoice (PDF/Image)
              </label>
              <div className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-colors ${
                isDark 
                  ? 'border-[#334155] hover:border-blue-500 bg-[#111827]' 
                  : 'border-slate-300 hover:border-blue-500 bg-slate-50'
              }`}>
                <input
                  type="file"
                  accept="application/pdf,image/*"
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <div className="flex flex-col items-center gap-3">
                  <Upload className={`w-8 h-8 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`} />
                  <div className={`text-sm font-bold ${isDark ? 'text-[#CBD5E1]' : 'text-slate-700'}`}>
                    {file ? file.name : 'Click or drag file to upload'}
                  </div>
                  <div className={`text-xs ${isDark ? 'text-[#6B7280]' : 'text-slate-500'}`}>
                    Supports PDF, PNG, JPG
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label className={`block text-xs font-black uppercase tracking-widest mb-2 font-mono ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                2. User Prompt (Optional)
              </label>
              <input
                type="text"
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                placeholder="e.g., Extract items from Pinnacle Invoice #30137"
                className={`w-full px-4 py-3 rounded-xl text-sm font-bold focus:outline-none border transition-all ${
                  isDark ? 'bg-[#111827] border-[#1F2937] text-[#F9FAFB] focus:border-blue-500' : 'bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500'
                }`}
              />
            </div>

            <button
              onClick={handleExtract}
              disabled={!file || isProcessing}
              className={`w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-sm font-black uppercase tracking-widest transition-all ${
                !file || isProcessing
                  ? (isDark ? 'bg-[#1F2937] text-[#6B7280] cursor-not-allowed' : 'bg-slate-100 text-slate-400 cursor-not-allowed')
                  : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20'
              }`}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> Processing...
                </>
              ) : (
                'Extract Data'
              )}
            </button>

            {error && (
              <div className="flex items-start gap-3 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                <p className="text-sm font-medium">{error}</p>
              </div>
            )}
          </div>

          {/* Results Section */}
          <div className={`flex flex-col rounded-2xl border overflow-hidden ${isDark ? 'bg-[#111827] border-[#1F2937]' : 'bg-slate-50 border-slate-200'}`}>
            <div className={`px-6 py-4 border-b ${isDark ? 'border-[#1F2937] bg-[#0F172A]' : 'border-slate-200 bg-white'}`}>
              <h3 className={`text-xs font-black uppercase tracking-widest font-mono ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                Extracted Data
              </h3>
            </div>
            <div className="flex-1 p-6 overflow-auto max-h-[500px]">
              {extractedData ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-emerald-500">
                      <CheckCircle2 className="w-5 h-5" />
                      <span className="text-sm font-bold">Successfully extracted {extractedData.length} items</span>
                    </div>
                    <button
                      onClick={handleSaveToSupabase}
                      disabled={isSaving || saveSuccess}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${
                        saveSuccess
                          ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                          : isSaving
                          ? (isDark ? 'bg-[#1F2937] text-[#6B7280] cursor-not-allowed' : 'bg-slate-100 text-slate-400 cursor-not-allowed')
                          : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20'
                      }`}
                    >
                      {saveSuccess ? (
                        <>
                          <CheckCircle2 className="w-4 h-4" /> Saved
                        </>
                      ) : isSaving ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" /> Saving...
                        </>
                      ) : (
                        <>
                          <Database className="w-4 h-4" /> Save to Supabase
                        </>
                      )}
                    </button>
                  </div>
                  <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-[#1F2937]">
                    <table className="w-full text-left text-sm">
                      <thead className={`text-xs uppercase font-bold ${isDark ? 'bg-[#1F2937] text-[#94A3B8]' : 'bg-slate-50 text-slate-500'}`}>
                        <tr>
                          <th className="px-4 py-3">Date Stamp</th>
                          <th className="px-4 py-3">Order Date</th>
                          <th className="px-4 py-3">Vendor</th>
                          <th className="px-4 py-3">ABC# (BES)</th>
                          <th className="px-4 py-3">Item#</th>
                          <th className="px-4 py-3">NDC</th>
                          <th className="px-4 py-3">Description</th>
                          <th className="px-4 py-3">Pack Size</th>
                          <th className="px-4 py-3 text-right">Items/Box</th>
                          <th className="px-4 py-3 text-right">Qty</th>
                          <th className="px-4 py-3 text-right">Rate</th>
                          <th className="px-4 py-3 text-right">Price/Item</th>
                          <th className="px-4 py-3 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className={`divide-y ${isDark ? 'divide-[#1F2937]' : 'divide-slate-200'}`}>
                        {extractedData.map((item, idx) => (
                          <tr key={idx} className={`${isDark ? 'hover:bg-[#1F2937]/50 text-[#CBD5E1]' : 'hover:bg-slate-50 text-slate-700'}`}>
                            <td className="px-4 py-3 text-xs whitespace-nowrap">{item.invoice_date || '-'}</td>
                            <td className="px-4 py-3 text-xs whitespace-nowrap">{item.order_date || '-'}</td>
                            <td className="px-4 py-3 text-xs whitespace-nowrap font-bold">{item.vendor || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-blue-500 font-bold">{item.bes_number || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-slate-500 font-bold">{item.item_code || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-pink-500 font-bold">{formatNDC(item.ndc) || '-'}</td>
                            <td className="px-4 py-3 max-w-[200px] truncate" title={item.description}>{item.description}</td>
                            <td className="px-4 py-3 text-xs">{item.pack_size || '-'}</td>
                            <td className="px-4 py-3 text-right font-mono">{item.items_per_box || 1}</td>
                            <td className="px-4 py-3 text-right font-mono">{item.quantity}</td>
                            <td className="px-4 py-3 text-right font-mono">${item.unit_price?.toFixed(2)}</td>
                            <td className="px-4 py-3 text-right font-mono text-blue-500">${(item.unit_price / Math.max(item.items_per_box || 1, 1)).toFixed(2)}</td>
                            <td className="px-4 py-3 text-right font-mono">${item.total_amount?.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className={`h-full flex items-center justify-center text-sm font-medium ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                  {isProcessing ? 'Analyzing invoice...' : 'No data extracted yet'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceParser;
