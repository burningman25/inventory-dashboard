import React, { useState } from 'react';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { Upload, Image as ImageIcon, Loader2, AlertCircle, Table, Database, CheckCircle2 } from 'lucide-react';
import { supabase } from '../supabaseClient';
import { INFUSION_FAVORITES } from '../constants';
import { PINNACLE_ITEMS } from '../pinnacleConstants';
import { VAXSERVE_ITEMS } from '../vaxserveConstants';
import { formatNDC } from '../utils';

interface ImageAnalyzerProps {
  isDark: boolean;
}

interface ExtractedImageData {
  ndc: string | null;
  item_code: string | null;
  price_per_box: number | null;
  quantity: number | null;
  date_stamp: string | null;
  description: string | null;
  vendor: string | null;
}

const ImageAnalyzer: React.FC<ImageAnalyzerProps> = ({ isDark }) => {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [additionalPrompt, setAdditionalPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [result, setResult] = useState<ExtractedImageData[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setResult(null);
      setError(null);
      setSaveSuccess(false);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const base64 = reader.result.split(',')[1];
          resolve(base64);
        } else {
          reject(new Error('Failed to convert file to base64'));
        }
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleAnalyze = async () => {
    if (!file) {
      setError('Please select an image first.');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setResult(null);
    setSaveSuccess(false);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('Gemini API Key is missing. Please set it in your environment variables.');
      }

      const ai = new GoogleGenAI({ apiKey });
      const base64Data = await fileToBase64(file);

      const mimeType = file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');

      const allExistingItems = [
        ...INFUSION_FAVORITES.map(i => ({ description: i.description, bes_number: i.bes_number, item_number: i.item_number, ndc: i.ndc })),
        ...PINNACLE_ITEMS.map(i => ({ description: i.description, bes_number: null, item_number: null, ndc: null })),
        ...VAXSERVE_ITEMS.map(i => ({ description: i.description, bes_number: null, item_number: i.itemNumber, ndc: i.ndc }))
      ];

      const systemInstruction = `You are a specialized medical data extractor. Analyze the provided image (invoice, label, or document) and extract the following key information for all items found.

CRITICAL FIELD DEFINITIONS — do NOT mix these up:
- ndc: The National Drug Code (NDC#). Standard format is 5-4-2 with hyphens (e.g., "60793-0701-10"). This is NEVER the same as ABC# or item_number.
- bes_number: The ABC/BES internal warehouse number (ABC#). This is a long numeric ID (e.g., "10243654"). Found labeled "ABC#" or "BES#" on invoices.
- item_code: The shorter vendor item/order number (e.g., "708664"). Found labeled "Item Number", "ABC 6#", or "Item" on invoices. NOT the NDC.
- price_per_box: Price per Box
- quantity: QTY (Quantity)
- date_stamp: Date updated, ordered, or invoiced
- description: Brief item description
- vendor: e.g., Cencora, Pinnacle, VaxServe

CRITICAL: You MUST map the extracted item to one of the existing products if it is a match (even if slightly abbreviated or misspelled in the image). This ensures the product cards update correctly.
Here is the list of existing products:
${JSON.stringify(allExistingItems)}

If the item matches an existing product, use the EXACT "description", "bes_number", and "item_code" from the list above. If it is a completely new item, use the values found in the image.

Return ONLY a valid JSON array of objects with the following schema:
[
  {
    "ndc": "string or null — NDC# only, formatted as 5-4-2 (e.g. 60793-0701-10)",
    "bes_number": "string or null — ABC/BES warehouse number (ABC#)",
    "item_code": "string or null — shorter vendor item/order number",
    "price_per_box": "number or null",
    "quantity": "number or null",
    "date_stamp": "string or null",
    "description": "string or null",
    "vendor": "string or null"
  }
]`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType,
              },
            },
            { text: additionalPrompt ? `Additional instructions: ${additionalPrompt}` : 'Extract the data according to the schema.' }
          ]
        },
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error('Received empty response from the model.');
      }

      let parsedData: ExtractedImageData[];
      try {
        parsedData = JSON.parse(text);
      } catch (e) {
        const match = text.match(/\[[\s\S]*\]/);
        if (match) {
          parsedData = JSON.parse(match[0]);
        } else {
          throw new Error('Failed to parse the extracted data as JSON.');
        }
      }

      // Match item codes before setting result
      const enrichedData = parsedData.map((item: any, idx: number) => {
        let matchedBesNumber = item.bes_number || null;
        let matchedItemCode = item.item_code || null;

        if (item.ndc) {
          const cencoraMatch = INFUSION_FAVORITES.find(i => i.ndc === item.ndc);
          if (cencoraMatch) {
            matchedBesNumber = cencoraMatch.bes_number;
            matchedItemCode = cencoraMatch.item_number;
          }
        }

        if (!matchedBesNumber && item.description) {
          const cencoraMatch = INFUSION_FAVORITES.find(i => i.description.toLowerCase() === item.description?.toLowerCase());
          if (cencoraMatch) {
            matchedBesNumber = cencoraMatch.bes_number;
            matchedItemCode = cencoraMatch.item_number;
          }

          if (!matchedBesNumber) {
            const vaxserveMatch = VAXSERVE_ITEMS.find(i => i.description.toLowerCase() === item.description?.toLowerCase());
            if (vaxserveMatch) matchedItemCode = vaxserveMatch.itemNumber;
          }
        }

        return {
          ...item,
          bes_number: matchedBesNumber,
          item_code: matchedItemCode || `IMG-${Date.now()}-${idx}`
        };
      });

      setResult(enrichedData);
      // Automatically save to Supabase
      await handleSaveToInventory(enrichedData);
    } catch (err: any) {
      console.error('Extraction error:', err);
      setError(err.message || 'An error occurred during analysis.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveToInventory = async (dataToSave = result) => {
    if (!dataToSave || dataToSave.length === 0) return;

    setIsSaving(true);
    setError(null);
    setSaveSuccess(false);

    try {
      // Upsert data into 'inventory_items' table
      let payload = dataToSave.map((item, idx) => {
        return {
          item_code: item.item_code || `IMG-${Date.now()}-${idx}`,
          bes_number: item.bes_number || null,
          description: item.description || 'Unknown Item',
          quantity: item.quantity || 0,
          unit_price: item.price_per_box || 0,
          total_amount: (item.price_per_box || 0) * (item.quantity || 0),
          invoice_date: item.date_stamp,
          updated_at: new Date().toISOString(),
          ndc: item.ndc ? item.ndc.replace(/-/g, '').replace(/(\d{5})(\d{4})(\d{2})/, '$1-$2-$3') : null,
          vendor: item.vendor
        };
      });

      let { error: dbError } = await supabase
        .from('inventory_items')
        .upsert(payload, { onConflict: 'item_code' });

      if (dbError && (dbError.message.includes('schema cache') || dbError.message.includes('ndc') || dbError.message.includes('bes_number'))) {
        // Retry without new columns
        const payloadStripped = payload.map(p => {
          const { ndc, bes_number, ...rest } = p;
          return rest;
        });
        const retry = await supabase
          .from('inventory_items')
          .upsert(payloadStripped, { onConflict: 'item_code' });
        dbError = retry.error;
      }

      if (dbError) {
        throw new Error(dbError.message);
      }

      setSaveSuccess(true);
    } catch (err: any) {
      console.error('Supabase save error:', err);
      if (err.message?.includes('schema cache') || err.message?.includes('ndc')) {
        setError('Missing column in Supabase. Please run this SQL in your Supabase SQL Editor: ALTER TABLE inventory_items ADD COLUMN IF NOT EXISTS ndc TEXT;');
      } else {
        setError(err.message || 'Failed to save data to Supabase.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h2 className={`text-2xl font-black tracking-tight ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>
            Image Analyzer
          </h2>
          <p className={`text-sm mt-1 ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
            Upload an image and use Gemini to analyze it.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Upload & Controls */}
        <div className="lg:col-span-1 space-y-6">
          <div className={`p-6 rounded-2xl border ${isDark ? 'bg-[#0F172A] border-[#1F2937]' : 'bg-white border-slate-200'} shadow-sm`}>
            <h3 className={`text-sm font-bold uppercase tracking-wider mb-4 ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
              Upload Image
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-center w-full">
                <label className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-xl cursor-pointer transition-colors ${isDark ? 'border-[#334155] hover:border-pink-500 bg-[#1E293B]/50 hover:bg-[#1E293B]' : 'border-slate-300 hover:border-pink-500 bg-slate-50 hover:bg-slate-100'}`}>
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className={`w-8 h-8 mb-3 ${isDark ? 'text-[#64748B]' : 'text-slate-400'}`} />
                    <p className={`mb-2 text-sm font-medium ${isDark ? 'text-[#CBD5E1]' : 'text-slate-600'}`}>
                      <span className="font-bold text-pink-500">Click to upload</span> or drag and drop
                    </p>
                    <p className={`text-xs ${isDark ? 'text-[#64748B]' : 'text-slate-500'}`}>
                      PNG, JPG, JPEG, PDF
                    </p>
                  </div>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*,.pdf,application/pdf"
                    onChange={handleFileChange}
                  />
                </label>
              </div>

              {file && (
                <div className={`flex items-center gap-3 p-3 rounded-lg ${isDark ? 'bg-[#1E293B]' : 'bg-slate-50'}`}>
                  <ImageIcon className="w-5 h-5 text-pink-500" />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${isDark ? 'text-[#F9FAFB]' : 'text-slate-900'}`}>
                      {file.name}
                    </p>
                    <p className={`text-xs ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className={`text-xs font-bold uppercase tracking-wider ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                  Additional Instructions (Optional)
                </label>
                <textarea
                  value={additionalPrompt}
                  onChange={(e) => setAdditionalPrompt(e.target.value)}
                  className={`w-full h-20 px-3 py-2 text-sm rounded-lg border focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all ${isDark ? 'bg-[#1E293B] border-[#334155] text-[#F9FAFB] placeholder-[#64748B]' : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'}`}
                  placeholder="Any specific details to look out for?"
                />
              </div>

              <button
                onClick={handleAnalyze}
                disabled={!file || isProcessing}
                className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-bold text-white transition-all ${!file || isProcessing ? 'bg-slate-400 cursor-not-allowed' : 'bg-pink-600 hover:bg-pink-700 shadow-md shadow-pink-500/20'}`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Analyzing...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-4 h-4" /> Analyze Image
                  </>
                )}
              </button>

              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p>{error}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Preview & Results */}
        <div className="lg:col-span-2 space-y-6">
          <div className={`h-full min-h-[500px] p-6 rounded-2xl border flex flex-col ${isDark ? 'bg-[#0F172A] border-[#1F2937]' : 'bg-white border-slate-200'} shadow-sm`}>
            <div className="flex justify-between items-center mb-4">
              <h3 className={`text-sm font-bold uppercase tracking-wider ${isDark ? 'text-[#94A3B8]' : 'text-slate-500'}`}>
                Analysis Result
              </h3>
              {result && result.length > 0 && (
                <button
                  onClick={handleSaveToInventory}
                  disabled={isSaving || saveSuccess}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                    saveSuccess 
                      ? 'bg-emerald-500/10 text-emerald-500 cursor-default'
                      : isDark 
                        ? 'bg-[#1E293B] hover:bg-[#334155] text-[#F9FAFB]' 
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-900'
                  }`}
                >
                  {isSaving ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</>
                  ) : saveSuccess ? (
                    <><CheckCircle2 className="w-4 h-4" /> Saved to Inventory</>
                  ) : (
                    <><Database className="w-4 h-4" /> Apply to Product Cards</>
                  )}
                </button>
              )}
            </div>
            
            <div className={`flex-1 rounded-xl border overflow-hidden flex flex-col ${isDark ? 'bg-[#1E293B] border-[#334155]' : 'bg-slate-50 border-slate-200'}`}>
              {previewUrl && (
                <div className="p-4 border-b border-slate-200 dark:border-[#334155] flex justify-center bg-black/5 dark:bg-black/20">
                  {file?.type === 'application/pdf' || file?.name.toLowerCase().endsWith('.pdf') ? (
                    <object data={previewUrl} type="application/pdf" className="w-full h-64 rounded-lg shadow-sm">
                      <div className="flex items-center justify-center h-full text-sm text-slate-500">PDF Document Selected</div>
                    </object>
                  ) : (
                    <img src={previewUrl} alt="Preview" className="max-h-64 object-contain rounded-lg shadow-sm" />
                  )}
                </div>
              )}
              
              <div className="p-0 flex-1 overflow-y-auto">
                {result ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className={`text-xs uppercase font-bold ${isDark ? 'bg-[#1F2937] text-[#94A3B8]' : 'bg-slate-50 text-slate-500'}`}>
                        <tr>
                          <th className="px-4 py-3">Date Stamp</th>
                          <th className="px-4 py-3">Vendor</th>
                          <th className="px-4 py-3">ABC# (BES)</th>
                          <th className="px-4 py-3">Item#</th>
                          <th className="px-4 py-3">NDC</th>
                          <th className="px-4 py-3">Description</th>
                          <th className="px-4 py-3 text-right">Qty</th>
                          <th className="px-4 py-3 text-right">Price/Box</th>
                        </tr>
                      </thead>
                      <tbody className={`divide-y ${isDark ? 'divide-[#1F2937]' : 'divide-slate-200'}`}>
                        {result.map((item, idx) => (
                          <tr key={idx} className={`${isDark ? 'hover:bg-[#1F2937]/50 text-[#CBD5E1]' : 'hover:bg-slate-50 text-slate-700'}`}>
                            <td className="px-4 py-3 text-xs whitespace-nowrap">{item.date_stamp || '-'}</td>
                            <td className="px-4 py-3 text-xs font-bold">{item.vendor || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-blue-500 font-bold">{item.bes_number || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-slate-500 font-bold">{item.item_code?.startsWith('IMG-') ? '-' : item.item_code || '-'}</td>
                            <td className="px-4 py-3 font-mono text-xs text-pink-500 font-bold">{formatNDC(item.ndc) || '-'}</td>
                            <td className="px-4 py-3 max-w-[200px] truncate" title={item.description || ''}>{item.description || '-'}</td>
                            <td className="px-4 py-3 text-right font-mono">{item.quantity !== null ? item.quantity : '-'}</td>
                            <td className="px-4 py-3 text-right font-mono text-emerald-500">{item.price_per_box !== null ? `$${item.price_per_box.toFixed(2)}` : '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className={`h-full min-h-[200px] flex items-center justify-center text-sm font-medium ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>
                    {isProcessing ? 'Analyzing image with Gemini...' : 'Upload an image and click analyze to extract data.'}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageAnalyzer;
