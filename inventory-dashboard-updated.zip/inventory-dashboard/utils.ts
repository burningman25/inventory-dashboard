/**
 * Formats an NDC (National Drug Code) to the standard 5-4-2 hyphenated format.
 * Accepts codes with or without hyphens (11 raw digits → "XXXXX-XXXX-XX").
 * Already-formatted codes (e.g. "23155-0290-42") are returned as-is.
 * Returns null/undefined inputs unchanged.
 */
export function formatNDC(ndc: string | null | undefined): string {
  if (!ndc) return ndc as string;
  // Strip existing hyphens to normalize
  const digits = ndc.replace(/-/g, '');
  if (digits.length === 11) {
    return `${digits.slice(0, 5)}-${digits.slice(5, 9)}-${digits.slice(9)}`;
  }
  // If already formatted or unexpected length, return as-is
  return ndc;
}
