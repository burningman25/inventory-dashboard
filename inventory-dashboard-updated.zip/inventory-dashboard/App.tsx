
import React, { useState, useEffect } from 'react';
import CencoraDashboard from './components/CencoraDashboard';
import PinnacleDashboard from './components/PinnacleDashboard';
import VaxServeDashboard from './components/VaxServeDashboard';
import SupplyOrderSheet from './SupplyOrderSheet';
import InvoiceParser from './components/InvoiceParser';
import ImageAnalyzer from './components/ImageAnalyzer';

type Tab = 'CENCORA' | 'PINNACLE' | 'VAXSERVE' | 'SUPPLY_ORDER' | 'INVOICE_PARSER' | 'IMAGE_ANALYZER';
type Theme = 'dark' | 'light';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('CENCORA');
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('theme');
    return (saved as Theme) || 'dark';
  });

  useEffect(() => {
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  const isDark = theme === 'dark';

  const getBrandingColor = () => {
    if (activeTab === 'CENCORA') return isDark ? 'bg-[#22C55E]' : 'bg-emerald-600';
    if (activeTab === 'PINNACLE') return isDark ? 'bg-blue-500' : 'bg-blue-600';
    if (activeTab === 'VAXSERVE') return isDark ? 'bg-violet-500' : 'bg-violet-600';
    if (activeTab === 'INVOICE_PARSER') return isDark ? 'bg-cyan-500' : 'bg-cyan-600';
    if (activeTab === 'IMAGE_ANALYZER') return isDark ? 'bg-pink-500' : 'bg-pink-600';
    return isDark ? 'bg-amber-500' : 'bg-amber-600';
  };

  const getBrandingText = () => {
    if (activeTab === 'CENCORA') return 'CENCORA INFUSION';
    if (activeTab === 'PINNACLE') return 'PINNACLE DIST.';
    if (activeTab === 'VAXSERVE') return 'VAXSERVE';
    if (activeTab === 'INVOICE_PARSER') return 'INVOICE PARSER';
    if (activeTab === 'IMAGE_ANALYZER') return 'IMAGE ANALYZER';
    return 'SUPPLY ORDER';
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 ${isDark ? 'bg-[#0B1220]' : 'bg-[#F8FAFC]'}`}>
      <nav className={`${isDark ? 'bg-[#0F172A] border-[#1F2937]' : 'bg-white border-slate-200 shadow-sm'} border-b sticky top-0 z-50 transition-all duration-500`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6 sm:gap-8">
              {/* Branding */}
              <div className="flex items-center gap-3">
                <div className={`${getBrandingColor()} p-1.5 sm:p-2 rounded-lg shadow-lg transition-all duration-500`}>
                  <svg className={`w-5 h-5 sm:w-6 sm:h-6 ${isDark ? 'text-[#0B1220]' : 'text-white'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h1 className={`text-lg sm:text-xl font-black tracking-tighter uppercase transition-colors duration-500 ${isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]'}`}>
                  {getBrandingText()}
                </h1>
              </div>

              {/* Tabs Switcher */}
              <div className={`hidden sm:flex h-10 items-center gap-1 p-1 rounded-xl transition-colors duration-500 ${isDark ? 'bg-[#111827]' : 'bg-slate-100'}`}>
                <button 
                  onClick={() => setActiveTab('CENCORA')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'CENCORA' ? (isDark ? 'bg-[#1F2937] text-[#22C55E]' : 'bg-white text-emerald-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  Cencora
                </button>
                <button 
                  onClick={() => setActiveTab('PINNACLE')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'PINNACLE' ? (isDark ? 'bg-[#1F2937] text-blue-400' : 'bg-white text-blue-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  Pinnacle
                </button>
                <button 
                  onClick={() => setActiveTab('VAXSERVE')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'VAXSERVE' ? (isDark ? 'bg-[#1F2937] text-violet-400' : 'bg-white text-violet-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  VaxServe
                </button>
                <button 
                  onClick={() => setActiveTab('INVOICE_PARSER')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'INVOICE_PARSER' ? (isDark ? 'bg-[#1F2937] text-cyan-400' : 'bg-white text-cyan-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  Invoice Parser
                </button>
                <button 
                  onClick={() => setActiveTab('IMAGE_ANALYZER')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'IMAGE_ANALYZER' ? (isDark ? 'bg-[#1F2937] text-pink-400' : 'bg-white text-pink-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  Image Analyzer
                </button>
                <button 
                  onClick={() => setActiveTab('SUPPLY_ORDER')}
                  className={`px-4 py-1.5 text-xs font-black rounded-lg transition-all uppercase tracking-wider ${activeTab === 'SUPPLY_ORDER' ? (isDark ? 'bg-[#1F2937] text-amber-400' : 'bg-white text-amber-600 shadow-sm') : 'text-slate-500 hover:text-slate-800'}`}
                >
                  Supply Order
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 sm:gap-6">
              {/* Theme Toggle */}
              <button 
                onClick={toggleTheme}
                className={`p-2 rounded-full transition-all duration-300 ${isDark ? 'bg-[#1F2937] text-[#F59E0B] hover:bg-[#2D3748]' : 'bg-slate-100 text-amber-500 hover:bg-slate-200'} flex items-center justify-center`}
                aria-label="Toggle theme"
              >
                {isDark ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
                )}
              </button>

              {/* Right Side Branding */}
              <div className="flex flex-col items-end leading-none border-l pl-4 sm:pl-6 border-slate-200/20 dark:border-[#1F2937]">
                <span className={`text-[10px] font-black tracking-[0.2em] uppercase transition-colors duration-500 ${isDark ? 'text-[#6B7280]' : 'text-slate-400'}`}>Authenticated Org</span>
                <span className={`text-sm font-black tracking-tight transition-colors duration-500 ${isDark ? 'text-[#F9FAFB]' : 'text-[#1E293B]'}`}>ID CONSULTANTS INC</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-12 transition-colors duration-500 ${isDark ? 'bg-[#0B1220]' : 'bg-[#F8FAFC]'}`}>
        {activeTab === 'CENCORA' && <CencoraDashboard isDark={isDark} />}
        {activeTab === 'PINNACLE' && <PinnacleDashboard isDark={isDark} />}
        {activeTab === 'VAXSERVE' && <VaxServeDashboard isDark={isDark} />}
        {activeTab === 'INVOICE_PARSER' && <InvoiceParser isDark={isDark} />}
        {activeTab === 'IMAGE_ANALYZER' && <ImageAnalyzer isDark={isDark} />}
        {activeTab === 'SUPPLY_ORDER' && <SupplyOrderSheet isDark={isDark} />}
      </main>
    </div>
  );
};

export default App;
