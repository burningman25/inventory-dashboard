
export type OrderUnit = 'Boxes' | 'Cases' | 'Vials' | 'Packages';

export interface OrderSelection {
  quantity: number;
  unit: OrderUnit;
}

export interface InfusionItem {
  description: string;
  bes_number: string;
  item_number: string;
  ndc: string | null;
  hcpcs: string | null;
  manufacturer: string | null;
  form: string | null;
  unit: string;
  unit_price: number;
  status: 'STOCKED' | 'OUT OF STOCK';
  notes?: string;
  recovery_date?: string;
  case_info?: string;
  quantity?: number;
  last_updated?: string;
}

export interface PinnacleItem {
  description: string;
  price: number;
  stock: 'IN_STOCK' | 'OUT_OF_STOCK';
  caseInfo: string;
}

export interface VaxServeItem {
  productName: string;
  description: string;
  details: string;
  ndc: string;
  itemNumber: string;
  manufacturer: string;
  price: number;
  doseCount: number;
  status: 'IN_STOCK' | 'OUT_OF_STOCK';
}

export interface SummaryStats {
  totalItems: number;
  stockedCount: number;
  outOfStockCount: number;
  totalValue: number;
  avgPrice: number;
}
